package com.hcl.smartasset.advisor.app.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.smartasset.advisor.app.model.AccountProfile;
import com.hcl.smartasset.advisor.app.model.BasketRecommendation;
import com.hcl.smartasset.advisor.app.model.Positions;

@Repository
public class BasketRecommendationRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Transactional
	public boolean authenticateUser(String userId, String password) {
		List<String> user = jdbcTemplate.query("select user_id from user_account where user_id =? AND password =?",
				new Object[] { userId, password }, (rs, rowNum) -> rs.getString("user_id"));
		if (null != user && user.size() > 0) {
			return true;
		}
		return false;

	}

	@Transactional
	public AccountProfile fetchAccountDetailsByUserId(String userId) {

		return jdbcTemplate.queryForObject("select * from user_account where user_id =?",
				new Object[] { userId },
				(rs, rowNum) -> new AccountProfile
				(rs.getString("user_id"), 
						rs.getString("password"),
						rs.getString("account_number"), 
						rs.getString("dob"), 
						rs.getString("address"),
						rs.getString("city"), 
						rs.getString("state"), 
						rs.getString("country"),
						rs.getString("zipcode"),
						rs.getString("option_trader_flag"), 
						rs.getString("day_trader_flag"),
						rs.getString("margin_trader_flag"),
						rs.getString("email"),
						rs.getString("first_name"),
						rs.getString("last_name"),
						rs.getString("ssn"),
						rs.getString("phone_number"),
						rs.getString("bank_account_number"),
						rs.getString("bank_name")
						
						
						
				));

	}

	@Transactional
	public Positions findPositionsByUserId(String userId) {

		return jdbcTemplate.queryForObject("select * from positions where user_id =?",
				new Object[] { userId },
				(rs, rowNum) -> new Positions(rs.getString("user_id"), rs.getString("account_number"),
						rs.getString("etf_holding_flag"), rs.getString("bonds_holding_flag"),
						rs.getString("options_holding_flag"), rs.getString("sgl_lgl"),
						rs.getString("equities_holding_flag")

				));
	}
@Transactional
	public List<BasketRecommendation> fetchbasketdetails(String riskType) {
		
		
		return jdbcTemplate.query("select * from baskets where risk_type =?",
				new Object[] { riskType },
				(rs, rowNum) -> new BasketRecommendation(rs.getString("basket_name")
						, rs.getString("description"),
						rs.getString("risk_category"), 
						rs.getString("minimum_amount"),
						rs.getString("risk_score"),
						rs.getString("risk_type"),
						rs.getString("category"),
						rs.getString("image_url")

				));

		
	}

	/*
	 * public AccountProfile fetchAccountDetailsByUserId(String userId) { // TODO
	 * Auto-generated method stub return
	 * jdbcTemplate.queryForObject("select * from user_account where user_id =?",
	 * new Object[] { userId }, (rs, rowNum) -> new
	 * AccountProfile(rs.getString("user_id"), rs.getString("password"),
	 * rs.getString("account_number"), rs.getString("dob"), rs.getString("address"),
	 * rs.getString("city"), rs.getString("state"), rs.getString("country"),
	 * rs.getString("zipcode"), rs.getString("option_trader_flag"),
	 * rs.getString("day_trader_flag"), rs.getString("margin_trader_flag")
	 * 
	 * ));
	 * 
	 * }
	 */
}