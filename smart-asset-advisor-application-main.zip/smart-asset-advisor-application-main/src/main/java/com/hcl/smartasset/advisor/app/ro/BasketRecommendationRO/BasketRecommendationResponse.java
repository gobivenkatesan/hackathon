package com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO;

import java.util.List;
import java.util.Set;

public class BasketRecommendationResponse {
	
	private Set<String> categories;
	
	private List<MomentumInvesting> momentumInvestings;
	
	private List<ExchangeTradeFund> exchangeTradeFunds;
	
	private List<ScientficInvesting> scientficInvestings;
	
	private List<LongTermInvesting> longTermInvestings;
	
	private List<InvestmentGuruMethodology> investmentGuruMethodologies;
	
	private List<ValueInvesting> valueInvestings;
	
	private List<GrowthInvesting> growthInvestings;
	
	private List<ThematicInvesting> thematicInvestings;
	
	private List<CryptoCurrency> cryptoCurrencies;

	public Set<String> getCategories() {
		return categories;
	}

	public void setCategories(Set<String> categories) {
		this.categories = categories;
	}

	public List<MomentumInvesting> getMomentumInvestings() {
		return momentumInvestings;
	}

	public void setMomentumInvestings(List<MomentumInvesting> momentumInvestings) {
		this.momentumInvestings = momentumInvestings;
	}

	public List<ExchangeTradeFund> getExchangeTradeFunds() {
		return exchangeTradeFunds;
	}

	public void setExchangeTradeFunds(List<ExchangeTradeFund> exchangeTradeFunds) {
		this.exchangeTradeFunds = exchangeTradeFunds;
	}

	public List<ScientficInvesting> getScientficInvestings() {
		return scientficInvestings;
	}

	public void setScientficInvestings(List<ScientficInvesting> scientficInvestings) {
		this.scientficInvestings = scientficInvestings;
	}

	public List<LongTermInvesting> getLongTermInvestings() {
		return longTermInvestings;
	}

	public void setLongTermInvestings(List<LongTermInvesting> longTermInvestings) {
		this.longTermInvestings = longTermInvestings;
	}

	public List<InvestmentGuruMethodology> getInvestmentGuruMethodologies() {
		return investmentGuruMethodologies;
	}

	public void setInvestmentGuruMethodologies(List<InvestmentGuruMethodology> investmentGuruMethodologies) {
		this.investmentGuruMethodologies = investmentGuruMethodologies;
	}

	public List<ValueInvesting> getValueInvestings() {
		return valueInvestings;
	}

	public void setValueInvestings(List<ValueInvesting> valueInvestings) {
		this.valueInvestings = valueInvestings;
	}

	public List<GrowthInvesting> getGrowthInvestings() {
		return growthInvestings;
	}

	public void setGrowthInvestings(List<GrowthInvesting> growthInvestings) {
		this.growthInvestings = growthInvestings;
	}

	public List<ThematicInvesting> getThematicInvestings() {
		return thematicInvestings;
	}

	public void setThematicInvestings(List<ThematicInvesting> thematicInvestings) {
		this.thematicInvestings = thematicInvestings;
	}

	public List<CryptoCurrency> getCryptoCurrencies() {
		return cryptoCurrencies;
	}

	public void setCryptoCurrencies(List<CryptoCurrency> cryptoCurrencies) {
		this.cryptoCurrencies = cryptoCurrencies;
	}

	@Override
	public String toString() {
		return "BasketRecommendationResponse [categories=" + categories + ", momentumInvestings=" + momentumInvestings
				+ ", exchangeTradeFunds=" + exchangeTradeFunds + ", scientficInvestings=" + scientficInvestings
				+ ", longTermInvestings=" + longTermInvestings + ", investmentGuruMethodologies="
				+ investmentGuruMethodologies + ", valueInvestings=" + valueInvestings + ", growthInvestings="
				+ growthInvestings + ", thematicInvestings=" + thematicInvestings + ", cryptoCurrencies="
				+ cryptoCurrencies + "]";
	}
	
	
	
	

	}
