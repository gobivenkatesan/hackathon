package com.hcl.smartasset.advisor.app.ro.AccountProfileRO;


public class MarketMood {
	
	
	private String  marketMoodValue;
	private String marketMoodLevel;
	
	
	private PreviousClose previousClose;
	
	private WeekAgo  weekAgo;
	
	private MonthAgo monthAgo;
	
	private YearAgo yearAgo;
	
	
	

	
	public String getMarketMoodLevel() {
		return marketMoodLevel;
	}

	public void setMarketMoodLevel(String marketMoodLevel) {
		this.marketMoodLevel = marketMoodLevel;
	}

	public String getMarketMoodValue() {
		return marketMoodValue;
	}

	public void setMarketMoodValue(String marketMoodValue) {
		this.marketMoodValue = marketMoodValue;
	}

	public PreviousClose getPreviousClose() {
		return previousClose;
	}

	public void setPreviousClose(PreviousClose previousClose) {
		this.previousClose = previousClose;
	}

	public WeekAgo getWeekAgo() {
		return weekAgo;
	}

	public void setWeekAgo(WeekAgo weekAgo) {
		this.weekAgo = weekAgo;
	}

	public MonthAgo getMonthAgo() {
		return monthAgo;
	}

	public void setMonthAgo(MonthAgo monthAgo) {
		this.monthAgo = monthAgo;
	}

	public YearAgo getYearAgo() {
		return yearAgo;
	}

	public void setYearAgo(YearAgo yearAgo) {
		this.yearAgo = yearAgo;
	}

	@Override
	public String toString() {
		return "MarketMood [marketMoodValue=" + marketMoodValue + ", marketMoodLevel=" + marketMoodLevel
				+ ", previousClose=" + previousClose + ", weekAgo=" + weekAgo + ", monthAgo=" + monthAgo + ", yearAgo="
				+ yearAgo + "]";
	}

	

	
}
