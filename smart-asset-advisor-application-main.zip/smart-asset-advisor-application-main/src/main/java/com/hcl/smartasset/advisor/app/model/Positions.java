package com.hcl.smartasset.advisor.app.model;

public class Positions {
	
	private String userId;
	
	private String accountNumber;
	
	private String etfHoldingFlag;
	
	private String equitiesHoldingFlag;
	
	private String bondsHoldingFlag;
	
	private String optionsHoldingFlag;
	
	private String sglLgl;
	
	
	public Positions()
	{
		
	}

	
	public Positions(String userId, String accountNumber, String etfHoldingFlag, String equitiesHoldingFlag,
			String bondsHoldingFlag, String optionsHoldingFlag, String sglLgl) {
		super();
		this.userId = userId;
		this.accountNumber = accountNumber;
		this.etfHoldingFlag = etfHoldingFlag;
		this.equitiesHoldingFlag = equitiesHoldingFlag;
		this.bondsHoldingFlag = bondsHoldingFlag;
		this.optionsHoldingFlag = optionsHoldingFlag;
		this.sglLgl = sglLgl;
	}


	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getEtfHoldingFlag() {
		return etfHoldingFlag;
	}

	public void setEtfHoldingFlag(String etfHoldingFlag) {
		this.etfHoldingFlag = etfHoldingFlag;
	}

	public String getBondsHoldingFlag() {
		return bondsHoldingFlag;
	}

	public void setBondsHoldingFlag(String bondsHoldingFlag) {
		this.bondsHoldingFlag = bondsHoldingFlag;
	}

	public String getOptionsHoldingFlag() {
		return optionsHoldingFlag;
	}

	public void setOptionsHoldingFlag(String optionsHoldingFlag) {
		this.optionsHoldingFlag = optionsHoldingFlag;
	}

	public String getSglLgl() {
		return sglLgl;
	}

	public void setSglLgl(String sglLgl) {
		this.sglLgl = sglLgl;
	}


	public String getEquitiesHoldingFlag() {
		return equitiesHoldingFlag;
	}


	public void setEquitiesHoldingFlag(String equitiesHoldingFlag) {
		this.equitiesHoldingFlag = equitiesHoldingFlag;
	}


	@Override
	public String toString() {
		return "Positions [userId=" + userId + ", accountNumber=" + accountNumber + ", etfHoldingFlag=" + etfHoldingFlag
				+ ", equitiesHoldingFlag=" + equitiesHoldingFlag + ", bondsHoldingFlag=" + bondsHoldingFlag
				+ ", optionsHoldingFlag=" + optionsHoldingFlag + ", sglLgl=" + sglLgl + "]";
	}

	
	
	

}
