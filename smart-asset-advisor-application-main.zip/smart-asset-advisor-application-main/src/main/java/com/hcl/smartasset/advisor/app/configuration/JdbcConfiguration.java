package com.hcl.smartasset.advisor.app.configuration;



import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
public class JdbcConfiguration
{
   @Bean
   public DataSource dataSource()
   {
      
	   System.out.println("Inside data base Connection ");
	   DriverManagerDataSource dataSource = new DriverManagerDataSource();

      dataSource.setDriverClassName("com.mysql.jdbc.Driver");
      dataSource.setUrl("jdbc:mysql://localhost:3306/smart_asset_advisor?useSSL=false");
      dataSource.setUsername("smartadvisor");
      dataSource.setPassword("Hackathon");

      return (DataSource) dataSource;
   }

   @Bean
   public NamedParameterJdbcTemplate namedParameterJdbcTemplate()
   {
      NamedParameterJdbcTemplate retBean
          = new NamedParameterJdbcTemplate((javax.sql.DataSource) dataSource());
       return retBean;
   }

   @Bean
   public DataSourceTransactionManager txnManager()
   {
      DataSourceTransactionManager txnManager
         = new DataSourceTransactionManager((javax.sql.DataSource) dataSource());
      return txnManager;
   }
}