package com.hcl.smartasset.advisor.app.mapper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.hcl.smartasset.advisor.app.model.BasketRecommendation;
import com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO.BasketRecommendationResponse;
import com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO.CryptoCurrency;
import com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO.ExchangeTradeFund;
import com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO.GrowthInvesting;
import com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO.InvestmentGuruMethodology;
import com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO.LongTermInvesting;
import com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO.MomentumInvesting;
import com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO.ScientficInvesting;
import com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO.ThematicInvesting;
import com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO.ValueInvesting;


public class BasketRecommendationMapper {

	public BasketRecommendationResponse mapBasketReccomendation(List<BasketRecommendation> basketRecommendation) {
		// TODO Auto-generated method stub
		
		BasketRecommendationResponse basketRecommendationResponse=new 
				BasketRecommendationResponse();
		Set<String> categoriesSet=new HashSet<String>();
		List<String> categoriesList=new ArrayList();
		List<MomentumInvesting> momentumInvestingsList=new ArrayList();
		List<ExchangeTradeFund>exchangeTradeFundsList=new ArrayList();
		List<ScientficInvesting> scientficInvestingsList=new ArrayList();
		List<LongTermInvesting>longTermInvestingsList=new ArrayList();
		List<InvestmentGuruMethodology>investmentGuruMethodologiesList=new ArrayList();
		List<ValueInvesting> valueInvestingsList=new ArrayList();
		List<GrowthInvesting> growthInvestingsList=new ArrayList();
		List<ThematicInvesting> thematicInvestingsList=new ArrayList();
		List<CryptoCurrency> cryptoCurrenciesList=new ArrayList();
		
		for (BasketRecommendation basketRecommendation2 : basketRecommendation) {
			
			
			//populate basket List 
			System.out.println("---categories Logic:"+basketRecommendation2.getCategory());
			//populate list of baskets
			if(basketRecommendation2.getCategory().equalsIgnoreCase("Momentum Investing")) {
				MomentumInvesting moInvesting=new MomentumInvesting();
				moInvesting.setCategory(basketRecommendation2.getCategory());
				moInvesting.setHeading(basketRecommendation2.getBasketName());
				moInvesting.setDescription(basketRecommendation2.getDescription());
				moInvesting.setRisk(basketRecommendation2.getRiskType());
				moInvesting.setImageURL(basketRecommendation2.getUrl());
				categoriesList.add("momentumInvestings");
				momentumInvestingsList.add(moInvesting);
				
			}else if(basketRecommendation2.getCategory().equalsIgnoreCase("Exchange Trade Fund (ETF)")) {
				ExchangeTradeFund exchangeTradeFund=new ExchangeTradeFund();
				exchangeTradeFund.setCategory(basketRecommendation2.getCategory());
				exchangeTradeFund.setHeading(basketRecommendation2.getBasketName());
				exchangeTradeFund.setDescription(basketRecommendation2.getDescription());
				exchangeTradeFund.setRisk(basketRecommendation2.getRiskType());
				exchangeTradeFund.setImageURL(basketRecommendation2.getUrl());
				categoriesList.add("exchangeTradeFunds");
				exchangeTradeFundsList.add(exchangeTradeFund);
				
			}else if(basketRecommendation2.getCategory().equalsIgnoreCase("Scientfic Investing")) {
				ScientficInvesting scientficInvesting=new ScientficInvesting();
				scientficInvesting.setCategory(basketRecommendation2.getCategory());
				scientficInvesting.setHeading(basketRecommendation2.getBasketName());
				scientficInvesting.setDescription(basketRecommendation2.getDescription());
				scientficInvesting.setRisk(basketRecommendation2.getRiskType());
				scientficInvesting.setImageURL(basketRecommendation2.getUrl());
				categoriesList.add("scientficInvestings");
				scientficInvestingsList.add(scientficInvesting);
				
			}else if(basketRecommendation2.getCategory().equalsIgnoreCase("Long Term Investing")) {
				LongTermInvesting longTermInvesting=new LongTermInvesting();
				longTermInvesting.setCategory(basketRecommendation2.getCategory());
				longTermInvesting.setHeading(basketRecommendation2.getBasketName());
				longTermInvesting.setDescription(basketRecommendation2.getDescription());
				longTermInvesting.setRisk(basketRecommendation2.getRiskType());
				longTermInvesting.setImageURL(basketRecommendation2.getUrl());
				categoriesList.add("longTermInvestings");
				longTermInvestingsList.add(longTermInvesting);
				
			}else if(basketRecommendation2.getCategory().
					equalsIgnoreCase("Investment Guru Methodology")) {
				InvestmentGuruMethodology investmentGuruMethodology=new InvestmentGuruMethodology();
				investmentGuruMethodology.setCategory(basketRecommendation2.getCategory());
				investmentGuruMethodology.setHeading(basketRecommendation2.getBasketName());
				investmentGuruMethodology.setDescription(basketRecommendation2.getDescription());
				investmentGuruMethodology.setRisk(basketRecommendation2.getRiskType());
				investmentGuruMethodology.setImageURL(basketRecommendation2.getUrl());
				categoriesList.add("investmentGuruMethodologies");
				investmentGuruMethodologiesList.add(investmentGuruMethodology);
				
			}else if(basketRecommendation2.getCategory().
					equalsIgnoreCase("Value Investing")) {
				ValueInvesting valueInvesting=new ValueInvesting();
				valueInvesting.setCategory(basketRecommendation2.getCategory());
				valueInvesting.setHeading(basketRecommendation2.getBasketName());
				valueInvesting.setDescription(basketRecommendation2.getDescription());
				valueInvesting.setRisk(basketRecommendation2.getRiskType());
				valueInvesting.setImageURL(basketRecommendation2.getUrl());
				categoriesList.add("valueInvestings");
				valueInvestingsList.add(valueInvesting);
				
			}else if(basketRecommendation2.getCategory().
					equalsIgnoreCase("Growth Investing")) {
				GrowthInvesting growthInvesting=new GrowthInvesting();
				growthInvesting.setCategory(basketRecommendation2.getCategory());
				growthInvesting.setHeading(basketRecommendation2.getBasketName());
				growthInvesting.setDescription(basketRecommendation2.getDescription());
				growthInvesting.setRisk(basketRecommendation2.getRiskType());
				growthInvesting.setImageURL(basketRecommendation2.getUrl());
				categoriesList.add("growthInvestings");
				growthInvestingsList.add(growthInvesting);
				
			}else if(basketRecommendation2.getCategory().
					equalsIgnoreCase("Thematic Investing")) {
				ThematicInvesting thematicInvesting=new ThematicInvesting();
				thematicInvesting.setCategory(basketRecommendation2.getCategory());
				thematicInvesting.setHeading(basketRecommendation2.getBasketName());
				thematicInvesting.setDescription(basketRecommendation2.getDescription());
				thematicInvesting.setRisk(basketRecommendation2.getRiskType());
				thematicInvesting.setImageURL(basketRecommendation2.getUrl());
				categoriesList.add("thematicInvestings");
				thematicInvestingsList.add(thematicInvesting);
				
			}else if(basketRecommendation2.getCategory().
					equalsIgnoreCase("Crypto Currency")  &&
					(basketRecommendation2.getRiskType().equalsIgnoreCase("Very Aggressive")||
						basketRecommendation2.getRiskType().equalsIgnoreCase("Aggressive"))) {
				CryptoCurrency cryptoCurrency=new CryptoCurrency();
				cryptoCurrency.setHeading(basketRecommendation2.getBasketName());
				cryptoCurrency.setDescription(basketRecommendation2.getDescription());
				cryptoCurrency.setRisk(basketRecommendation2.getRiskType());
				cryptoCurrency.setImageURL(basketRecommendation2.getUrl());
				
					cryptoCurrency.setCategory(basketRecommendation2.getCategory());
					
					categoriesList.add("cryptoCurrencies");
				
				
				cryptoCurrenciesList.add(cryptoCurrency);
				
			}
			
			
			
			
			
			
			
			
			
		}
		
		for (String categories : categoriesList) {
			categoriesSet.add(categories);
			
		}
		basketRecommendationResponse.setCategories(categoriesSet);
		basketRecommendationResponse.setCryptoCurrencies(cryptoCurrenciesList);
		basketRecommendationResponse.setExchangeTradeFunds(exchangeTradeFundsList);
		basketRecommendationResponse.setGrowthInvestings(growthInvestingsList);
		basketRecommendationResponse.setInvestmentGuruMethodologies(investmentGuruMethodologiesList);
		basketRecommendationResponse.setLongTermInvestings(longTermInvestingsList);
		basketRecommendationResponse.setMomentumInvestings(momentumInvestingsList);
		basketRecommendationResponse.setScientficInvestings(scientficInvestingsList);
		basketRecommendationResponse.setThematicInvestings(thematicInvestingsList);
		basketRecommendationResponse.setValueInvestings(valueInvestingsList);
		//basketRecommendationResponse
		return basketRecommendationResponse;
	}

}
