package com.hcl.smartasset.advisor.app.ro.AccountProfileRO;

import java.util.List;

import com.hcl.smartasset.advisor.app.ro.BankAccounts;
import com.hcl.smartasset.advisor.app.ro.Eligibility;
import com.hcl.smartasset.advisor.app.ro.Holdings;

public class AccountProfileResponse {
	
	private String firstName;
	
	private String lastName;
	
	private String mailId;
	
	private String ssn;
	
	private String phone;
	
	private String age;
	
	
	private List<Eligibility> eligibility;
	
	private List<Holdings> holdings;
	
	private BankAccounts bankAccounts;
	
	private MarketMood marketMood;
	
	
	

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	
	public List<Eligibility> getEligibility() {
		return eligibility;
	}

	public void setEligibility(List<Eligibility> eligibility) {
		this.eligibility = eligibility;
	}

	public List<Holdings> getHoldings() {
		return holdings;
	}

	public void setHoldings(List<Holdings> holdings) {
		this.holdings = holdings;
	}

	public BankAccounts getBankAccounts() {
		return bankAccounts;
	}

	public void setBankAccounts(BankAccounts bankAccounts) {
		this.bankAccounts = bankAccounts;
	}

	public MarketMood getMarketMood() {
		return marketMood;
	}

	public void setMarketMood(MarketMood marketMood) {
		this.marketMood = marketMood;
	}

	@Override
	public String toString() {
		return "AccountProfileResponse [firstName=" + firstName + ", lastName=" + lastName + ", mailId=" + mailId
				+ ", ssn=" + ssn + ", phone=" + phone + ", age=" + age + ", eligibility=" + eligibility + ", holdings="
				+ holdings + ", bankAccounts=" + bankAccounts + ", marketMood=" + marketMood + "]";
	}

	
		
	
		
	
	
}
