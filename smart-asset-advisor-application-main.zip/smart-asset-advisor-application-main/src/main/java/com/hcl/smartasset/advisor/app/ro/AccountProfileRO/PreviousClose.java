package com.hcl.smartasset.advisor.app.ro.AccountProfileRO;

public class PreviousClose {
	
private String  value;
	
	private String level;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	@Override
	public String toString() {
		return "PreviousClose [value=" + value + ", level=" + level + "]";
	}

	
}
