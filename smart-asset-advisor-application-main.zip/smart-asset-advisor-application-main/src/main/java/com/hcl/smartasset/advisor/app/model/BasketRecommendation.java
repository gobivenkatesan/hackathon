package com.hcl.smartasset.advisor.app.model;

public class BasketRecommendation {
	
	private String basketName;
	
	private String description;
	
	private String riskCategory;
	
	private String minimumAmount;
	
	private String riskScore;
	
	private String riskType;
	
	private String category;
	
	private String url;

	
	
	
	
	public BasketRecommendation(String basketName, String description, String riskCategory, String minimumAmount,
			String riskScore, String riskType, String category, String url) {
		super();
		this.basketName = basketName;
		this.description = description;
		this.riskCategory = riskCategory;
		this.minimumAmount = minimumAmount;
		this.riskScore = riskScore;
		this.riskType = riskType;
		this.category = category;
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getBasketName() {
		return basketName;
	}

	public void setBasketName(String basketName) {
		this.basketName = basketName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRiskCategory() {
		return riskCategory;
	}

	public void setRiskCategory(String riskCategory) {
		this.riskCategory = riskCategory;
	}

	public String getMinimumAmount() {
		return minimumAmount;
	}

	public void setMinimumAmount(String minimumAmount) {
		this.minimumAmount = minimumAmount;
	}

	public String getRiskScore() {
		return riskScore;
	}

	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}

	public String getRiskType() {
		return riskType;
	}

	public void setRiskType(String riskType) {
		this.riskType = riskType;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "BasketRecommendation [basketName=" + basketName + ", description=" + description + ", riskCategory="
				+ riskCategory + ", minimumAmount=" + minimumAmount + ", riskScore=" + riskScore + ", riskType="
				+ riskType + ", category=" + category + ", url=" + url + "]";
	}

	
	
	
	
	
	
	

}
