package com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO;

public class LongTermInvesting {
	private String category;
	
	private String heading;
		
		private String description;
		
		private String risk;

		private String imageURL;
		
		
		
		public String getCategory() {
			return category;
		}

		public void setCategory(String category) {
			this.category = category;
		}

		public String getImageURL() {
			return imageURL;
		}

		public void setImageURL(String imageURL) {
			this.imageURL = imageURL;
		}

		public String getHeading() {
			return heading;
		}

		public void setHeading(String heading) {
			this.heading = heading;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getRisk() {
			return risk;
		}

		public void setRisk(String risk) {
			this.risk = risk;
		}

		@Override
		public String toString() {
			return "CryptoCurrency [category=" + category + ", heading=" + heading + ", description=" + description
					+ ", risk=" + risk + ", imageURL=" + imageURL + "]";
		}

		

		



}
