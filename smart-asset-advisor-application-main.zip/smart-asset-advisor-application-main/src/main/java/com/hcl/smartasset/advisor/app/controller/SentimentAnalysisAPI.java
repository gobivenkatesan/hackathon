package com.hcl.smartasset.advisor.app.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class SentimentAnalysisAPI {

	@GetMapping("/sentimentAnalysis/{symbol}")
	public String getSentimentAnalysisDetails(@PathVariable(value = "symbol") String symbol)
	{
		String documentText = symbol;
		String isTwitter = "true";
		String userCategoryModelName = "";
		String privateKey = "672EC945-AFDF-47FF-83AC-76A6585BC432";
		//"17C1F205-5DCA-47C5-95F8-645178AE9814";
		
		// add your private key here (you can find it in the admin panel once you
		// sign-up)
		String secret = "WASAAPI";// this should be set-up in admin panel as well

		StringBuilder result = new StringBuilder();
		String payload = "{" + "\"DocumentText\":\"" + documentText + "\", " + "\"IsTwitterContent\":\"" + isTwitter
				+ "\", " + "\"UserCategoryModelName\":\"" + userCategoryModelName + "\", " + "\"PrivateKey\":\""
				+ privateKey + "\", " + "\"Secret\":\"" + secret + "\", " + "\"RequestIdentifier\":\"" + "" + "\" "
				+ "}";

		// make request
		StringEntity entity = new StringEntity(payload, ContentType.create("application/json"));
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		HttpPost post = new HttpPost("http://api.text2data.com/v3/analyze");
		post.setEntity(entity);

		HttpResponse response = null;
		try {
			response = httpClient.execute(post);
			BufferedReader readBuffer = null;
			readBuffer = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			String line = "";
			while ((line = readBuffer.readLine()) != null) 
			{
				result.append(line);
			}

			JSONObject jsonObj = new JSONObject(result.toString());
			int status = (int) jsonObj.get("Status");

			System.out.println("status " + status);

			if (status == 1) {
				System.out.println(
						String.format("DocSentimentValue: %1s%2s %3.4f", jsonObj.getString("DocSentimentPolarity"),
								jsonObj.getString("DocSentimentResultString"), jsonObj.get("DocSentimentValue")));

			}

		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (UnsupportedOperationException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result.toString();
	}
}