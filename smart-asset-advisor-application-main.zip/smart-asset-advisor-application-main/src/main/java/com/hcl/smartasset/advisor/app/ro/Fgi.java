package com.hcl.smartasset.advisor.app.ro;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Fgi {
	
	@JsonProperty("now")
	private Now now;
	
	
	@JsonProperty("previousClose")
	private PreviousClose previousClose;
	
	
	
	@JsonProperty("oneWeekAgo")
	private OneWeekAgo oneWeekAgo;
	
	
	@JsonProperty("oneMonthAgo")
	private OneMonthAgo oneMonthAgo;
	

	@JsonProperty("oneYearAgo")
	private OneYearAgo oneYearAgo;
	
	public Now getNow() {
		return now;
	}

	public void setNow(Now now) {
		this.now = now;
	}

	public OneMonthAgo getOneMonthAgo() {
		return oneMonthAgo;
	}

	public void setOneMonthAgo(OneMonthAgo oneMonthAgo) {
		this.oneMonthAgo = oneMonthAgo;
	}

	public OneWeekAgo getOneWeekAgo() {
		return oneWeekAgo;
	}

	public void setOneWeekAgo(OneWeekAgo oneWeekAgo) {
		this.oneWeekAgo = oneWeekAgo;
	}

	public PreviousClose getPreviousClose() {
		return previousClose;
	}

	public void setPreviousClose(PreviousClose previousClose) {
		this.previousClose = previousClose;
	}

	public OneYearAgo getOneYearAgo() {
		return oneYearAgo;
	}

	public void setOneYearAgo(OneYearAgo oneYearAgo) {
		this.oneYearAgo = oneYearAgo;
	}

	@Override
	public String toString() {
		return "Fgi [now=" + now + ", oneMonthAgo=" + oneMonthAgo + ", oneWeekAgo=" + oneWeekAgo + ", previousClose="
				+ previousClose + ", oneYearAgo=" + oneYearAgo + "]";
	}

	
	


}
