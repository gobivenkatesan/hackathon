package com.hcl.smartasset.advisor.app.model;

public class AccountProfile {
	
	
	private String userId;
	
	private String password;
	
	private String accountNumber;
	
	private String dateOfBirth;
	
	private String address;
	
	private String city;
	
	private String country;
	private String state;
	
	private String zipcode;
	
	private String optionTraderFlag;
	
	private String dayTraderFlag;
	
	private String marginTraderFlag;
	
	private String email;
	
	private String firstName;
	
	private String LastName;
	
	private String ssn;
	
	private String phone;
	
	private String bankAccountNumber;
	
	private String bankName;
	
	
	public AccountProfile() {
		
	}
	
	
	
	
	



	

	
	




	public AccountProfile(String userId, String password, String accountNumber, String dateOfBirth, String address,
			String city, String country, String state, String zipcode, String optionTraderFlag, String dayTraderFlag,
			String marginTraderFlag, String email, String firstName, String lastName, String ssn, String phone,
			String bankAccountNumber, String bankName) {
		super();
		this.userId = userId;
		this.password = password;
		this.accountNumber = accountNumber;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
		this.city = city;
		this.country = country;
		this.state = state;
		this.zipcode = zipcode;
		this.optionTraderFlag = optionTraderFlag;
		this.dayTraderFlag = dayTraderFlag;
		this.marginTraderFlag = marginTraderFlag;
		this.email = email;
		this.firstName = firstName;
		this.LastName = lastName;
		this.ssn = ssn;
		this.phone = phone;
		this.bankAccountNumber = bankAccountNumber;
		this.bankName = bankName;
	}
















	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getOptionTraderFlag() {
		return optionTraderFlag;
	}

	public void setOptionTraderFlag(String optionTraderFlag) {
		this.optionTraderFlag = optionTraderFlag;
	}

	public String getDayTraderFlag() {
		return dayTraderFlag;
	}

	public void setDayTraderFlag(String dayTraderFlag) {
		this.dayTraderFlag = dayTraderFlag;
	}

	public String getMarginTraderFlag() {
		return marginTraderFlag;
	}

	public void setMarginTraderFlag(String marginTraderFlag) {
		this.marginTraderFlag = marginTraderFlag;
	}

	
	
	public String getPassword() {
		return password;
	}




	public void setPassword(String password) {
		this.password = password;
	}








	public String getEmail() {
		return email;
	}








	public void setEmail(String email) {
		this.email = email;
	}








	public String getFirstName() {
		return firstName;
	}








	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}








	public String getLastName() {
		return LastName;
	}








	public void setLastName(String lastName) {
		LastName = lastName;
	}








	public String getSsn() {
		return ssn;
	}








	public void setSsn(String ssn) {
		this.ssn = ssn;
	}








	public String getPhone() {
		return phone;
	}








	public void setPhone(String phone) {
		this.phone = phone;
	}








	public String getBankAccountNumber() {
		return bankAccountNumber;
	}








	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}








	public String getBankName() {
		return bankName;
	}








	public void setBankName(String bankName) {
		this.bankName = bankName;
	}








	@Override
	public String toString() {
		return "AccountProfile [userId=" + userId + ", password=" + password + ", accountNumber=" + accountNumber
				+ ", dateOfBirth=" + dateOfBirth + ", address=" + address + ", city=" + city + ", country=" + country
				+ ", state=" + state + ", zipcode=" + zipcode + ", optionTraderFlag=" + optionTraderFlag
				+ ", dayTraderFlag=" + dayTraderFlag + ", marginTraderFlag=" + marginTraderFlag + ", email=" + email
				+ ", firstName=" + firstName + ", LastName=" + LastName + ", ssn=" + ssn + ", phone=" + phone
				+ ", bankAccountNumber=" + bankAccountNumber + ", bankName=" + bankName + "]";
	}








	




	




		
	
	
	



}
