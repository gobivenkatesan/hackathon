package com.hcl.smartasset.advisor.app.invoker;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcl.smartasset.advisor.app.ro.MarketMoodIndexResponse;


public class MarketMoodIndexInvoker {
	
	public MarketMoodIndexResponse getMarketMoodIndexDetails() 
	{
		//Positions postiPositions=null;
		MarketMoodIndexResponse marketMoodIndexResponse=new MarketMoodIndexResponse(); 
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create("https://fear-and-greed-index.p.rapidapi.com/v1/fgi"))
				.header("x-rapidapi-key", "47aa415e67msh7312394bd1fd154p1d0b3ajsn23673a43cd7e")
				.header("x-rapidapi-host", "fear-and-greed-index.p.rapidapi.com")
				.method("GET", HttpRequest.BodyPublishers.noBody())
				.build();
		HttpResponse<String> response = null;
		try 
		{
			response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
			
			System.out.println("response from HTTPResponse"+response.body());
			ObjectMapper objectMapper=new ObjectMapper();
			//Map<String, List<Posistions>> mapobj = new Hashmap<>
			marketMoodIndexResponse= objectMapper.readValue(response.body(), MarketMoodIndexResponse.class);
			System.out.println("response from HTTPResponse"+marketMoodIndexResponse.toString());
			
			//objectMapper.readValue(null, null)
			
			
			
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		} 
		catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
		System.out.println(response.body());
		return marketMoodIndexResponse;
	}

	


}
