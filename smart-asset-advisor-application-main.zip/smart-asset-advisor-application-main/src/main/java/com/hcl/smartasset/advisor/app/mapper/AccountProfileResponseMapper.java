package com.hcl.smartasset.advisor.app.mapper;

import java.util.ArrayList;
import java.util.List;

import com.hcl.smartasset.advisor.app.model.AccountProfile;
import com.hcl.smartasset.advisor.app.model.Positions;
import com.hcl.smartasset.advisor.app.ro.BankAccounts;
import com.hcl.smartasset.advisor.app.ro.Eligibility;
import com.hcl.smartasset.advisor.app.ro.Holdings;
import com.hcl.smartasset.advisor.app.ro.MarketMoodIndexResponse;
import com.hcl.smartasset.advisor.app.ro.AccountProfileRO.AccountProfileResponse;
import com.hcl.smartasset.advisor.app.ro.AccountProfileRO.MarketMood;
import com.hcl.smartasset.advisor.app.ro.AccountProfileRO.MonthAgo;
import com.hcl.smartasset.advisor.app.ro.AccountProfileRO.Now;
import com.hcl.smartasset.advisor.app.ro.AccountProfileRO.PreviousClose;
import com.hcl.smartasset.advisor.app.ro.AccountProfileRO.WeekAgo;
import com.hcl.smartasset.advisor.app.ro.AccountProfileRO.YearAgo;


public class AccountProfileResponseMapper {
	
	public static final String FLAG_TRUE ="Y";
	
	public static final String FLAG_FALSE ="N";
	

	public AccountProfileResponse mapResponseForAccountProfile(AccountProfile accountProfile,
			MarketMoodIndexResponse marketMoodResponse, AccountProfileResponse accountProfileResponse, Positions position) {
		// TODO Auto-generated method stub
		List<Eligibility> eligibilitiesList=new ArrayList();
		List<Holdings> holdingsList=new ArrayList();
		
		if(accountProfile!=null) {
			
			accountProfileResponse.setFirstName(accountProfile.getFirstName());
			accountProfileResponse.setLastName(accountProfile.getLastName());
			accountProfileResponse.setMailId(accountProfile.getEmail());
			accountProfileResponse.setSsn(accountProfile.getSsn());
			accountProfileResponse.setPhone(accountProfile.getPhone());
			
			//eligibities mapping 
			
			Eligibility eligibilityDay=new Eligibility();
			Eligibility eligibilityMargin=new Eligibility();
			Eligibility eligibilityoption=new Eligibility();
			eligibilityDay.setHeading("Day Trader");
			eligibilityDay.setValue(getFlag(accountProfile.getDayTraderFlag()));
			eligibilityMargin.setHeading("Margin Trader");
			eligibilityMargin.setValue(getFlag(accountProfile.getMarginTraderFlag()));
			eligibilityoption.setHeading("Option Trader");
			eligibilityoption.setValue(getFlag(accountProfile.getOptionTraderFlag()));
			eligibilitiesList.add(eligibilityDay);
			eligibilitiesList.add(eligibilityMargin);
			eligibilitiesList.add(eligibilityoption);
			accountProfileResponse.setEligibility(eligibilitiesList);
			
			 //BankAccount Mapping 
			
			BankAccounts bankAccounts=new BankAccounts();
			bankAccounts.setAccountNumber(accountProfile.getAccountNumber());
			bankAccounts.setBankName(accountProfile.getBankName());
			accountProfileResponse.setBankAccounts(bankAccounts);
			
		}
		
		if(position!=null) {
			
			//holdings Mapping
			
			Holdings holdingsEtf=new Holdings();
			Holdings holdingsbonds=new Holdings();
			Holdings holdingsEquity=new Holdings();
			Holdings holdingsNoPosition=new Holdings();
			
			holdingsEtf.setHeading("ETF");
			holdingsEtf.setValue(getFlag(position.getEtfHoldingFlag()));
			holdingsbonds.setHeading("Bonds");
			holdingsbonds.setValue(getFlag(position.getBondsHoldingFlag()));
			holdingsEquity.setHeading("Equity");
			holdingsEquity.setValue(getFlag(position.getEquitiesHoldingFlag()));
			holdingsNoPosition.setHeading("No-position");
			String noposition="Y";
			if(position.getBondsHoldingFlag().equalsIgnoreCase(FLAG_TRUE)||
					position.getEquitiesHoldingFlag().equalsIgnoreCase(FLAG_TRUE)||
					position.getOptionsHoldingFlag().equalsIgnoreCase(FLAG_TRUE) ||
					position.getEtfHoldingFlag().equalsIgnoreCase(FLAG_TRUE)) {
				noposition="N";
				
			}
			holdingsNoPosition.setValue(getFlag(noposition));
			
			holdingsList.add(holdingsEtf);
			holdingsList.add(holdingsbonds);
			holdingsList.add(holdingsEquity);
			holdingsList.add(holdingsNoPosition);
			accountProfileResponse.setHoldings(holdingsList);
		}
		
		
		//market Mood Index 
		//marketMoodResponse.getNow().getValue()
		//accountProfileResponse.setMarketMoodIndexResponse(marketMoodResponse);
		
		accountProfileResponse=mapMarketmoodmarketMoodResponse(marketMoodResponse,accountProfileResponse);
		
		
		
		return accountProfileResponse;
	}
	
	
	private AccountProfileResponse mapMarketmoodmarketMoodResponse(MarketMoodIndexResponse marketMoodResponse, AccountProfileResponse accountProfileResponse) {
		// TODO Auto-generated method stub
		
		if(marketMoodResponse!=null) {
			MarketMood marketMood=new MarketMood();
			//Now now =new Now();
			Integer nowvalue=marketMoodResponse.getFgi().getNow().getValue();
			
			double y = nowvalue / 100.0;
			marketMood.setMarketMoodValue(String.valueOf(y));
			
			marketMood.setMarketMoodLevel(marketMoodResponse.getFgi().getNow().getValueText());
			
			
			
			
			//now.setValue(String.valueOf(y));
			//now.setValueText(marketMoodResponse.getFgi().getNow().getValueText());
			
			PreviousClose previousClose=new PreviousClose();
			previousClose.setValue(
					Integer.toString
					(marketMoodResponse.getFgi().getPreviousClose().getValue()));
			previousClose.setLevel(marketMoodResponse.getFgi().getPreviousClose().getValueText());
			
			WeekAgo weekAgo=new WeekAgo();
			weekAgo.setValue(
					Integer.toString(
							marketMoodResponse.getFgi().getOneWeekAgo().getValue()));
			weekAgo.setLevel(marketMoodResponse.getFgi().getOneWeekAgo().getValueText());
			
			MonthAgo monthAgo=new MonthAgo();
			monthAgo.setValue(
					Integer.toString
					(marketMoodResponse.getFgi().getOneMonthAgo().getValue()));
			monthAgo.setLevel(marketMoodResponse.getFgi().getOneMonthAgo().getValueText());
			
			YearAgo yearAgo=new YearAgo();
			yearAgo.setValue(
			Integer.toString
			((marketMoodResponse.getFgi().getOneYearAgo().getValue())));
			yearAgo.setLevel(marketMoodResponse.getFgi().getOneYearAgo().getValueText());
		
			
			//marketMood.setNow(now);
			marketMood.setPreviousClose(previousClose);
			marketMood.setWeekAgo(weekAgo);
			marketMood.setMonthAgo(monthAgo);
			marketMood.setYearAgo(yearAgo);
			accountProfileResponse.setMarketMood(marketMood);
			
			
			
			//System.out.println("----MArket mood---"+marketMood.getNow().getValueText());
			
			
		
			
		}
		return accountProfileResponse;
	}


	public String getFlag(String flag) {
		if(flag.equalsIgnoreCase(FLAG_TRUE)){
			return "yes";
		}
		
		return "no";
		
		
		
	}

}
