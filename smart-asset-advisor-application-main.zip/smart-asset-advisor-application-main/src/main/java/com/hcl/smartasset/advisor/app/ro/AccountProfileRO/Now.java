package com.hcl.smartasset.advisor.app.ro.AccountProfileRO;

public class Now {
	
	
	private String  value;
	
	private String valueText;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValueText() {
		return valueText;
	}

	public void setValueText(String valueText) {
		this.valueText = valueText;
	}

	@Override
	public String toString() {
		return "Now [value=" + value + ", valueText=" + valueText + "]";
	}
	
	

}
