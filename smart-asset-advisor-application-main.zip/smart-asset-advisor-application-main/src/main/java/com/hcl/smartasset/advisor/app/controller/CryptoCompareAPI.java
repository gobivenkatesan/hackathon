package com.hcl.smartasset.advisor.app.controller;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class CryptoCompareAPI 
{
	@GetMapping("/cryptoCurrencyData/{symbol}")
	public String getCriptoCurrencyDetails(@PathVariable(value = "symbol") String symbol) 
	{
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create(
						"https://min-api.cryptocompare.com/data/pricemultifull?fsyms=" + symbol + "&tsyms=USD"))
				.header("api-key", "0af1b80ee097458635c21d768a7f333ae7142ef21446c874d18feec769545653")
				.method("GET", HttpRequest.BodyPublishers.noBody()).build();
		
		HttpResponse<String> response = null;
		try {
			response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return response.body();
	}
	@GetMapping("/cryptoCurrencyData")
	public String getCriptoCurrencyDetails() 
	{
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create(
						"https://min-api.cryptocompare.com/data/pricemultifull?fsyms=BTC,ETH,ADA,DOGE,LTC,XLM&tsyms=USD"))
				.header("api-key", "0af1b80ee097458635c21d768a7f333ae7142ef21446c874d18feec769545653")
				.method("GET", HttpRequest.BodyPublishers.noBody()).build();
			
		HttpResponse<String> response = null;
		try {
			response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return response.body();
	}
}
