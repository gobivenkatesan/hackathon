package com.hcl.smartasset.advisor.app.ro;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PreviousClose {
	@JsonProperty("value")
	private int value;
	@JsonProperty("valueText")
	private String valueText;

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String getValueText() {
		return valueText;
	}

	public void setValueText(String valueText) {
		this.valueText = valueText;
	}

	@Override
	public String toString() {
		return "Now [value=" + value + ", valueText=" + valueText + "]";
	}

}
