package com.hcl.smartasset.advisor.app.ro;

public class Eligibility {
	
	private String heading;
	
	private String value;

	public String getHeading() {
		return heading;
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	
	
	
	
	

}
