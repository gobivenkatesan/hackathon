package com.hcl.smartasset.advisor.app.ro;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MarketMoodIndexResponse {

	@JsonProperty("fgi")
	private Fgi fgi;

	public Fgi getFgi() {
		return fgi;
	}

	public void setFgi(Fgi fgi) {
		this.fgi = fgi;
	}

	@Override
	public String toString() {
		return "MarketMoodIndexResponse [fgi=" + fgi + "]";
	}
	
	
	
	
}
