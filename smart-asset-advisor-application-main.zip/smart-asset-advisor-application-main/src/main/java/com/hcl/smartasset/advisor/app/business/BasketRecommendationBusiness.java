package com.hcl.smartasset.advisor.app.business;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

import com.hcl.smartasset.advisor.app.model.AccountProfile;
import com.hcl.smartasset.advisor.app.model.Positions;

public class BasketRecommendationBusiness {
	
	public static final String FLAG_TRUE ="Y";
	
	public static final String FLAG_FALSE ="N";
	
	public static final String RISK_HIGH ="High";
	public static final String RISK_MEDIUM ="Medium";
	public static final String RISK_LOW ="Low";
	
	public static final String INDEX_GREED ="Greed";
	public static final String INDEX_EXTREME_FEAR ="Extreme Fear";
	public static final String INDEX_FEAR ="Fear";
	public static final String INDEX_EXTREME_GREED ="Extreme Greed";
	
	
	public String calculateRisk(AccountProfile accountProfile,Positions positions) throws ParseException {
		
		String risk ="";
		Integer age=null;
		
		//calculate Age 
		if(accountProfile.getDateOfBirth()!=null) {
			age=calculateAge(accountProfile.getDateOfBirth());
			
		}
		if(accountProfile.getDayTraderFlag().equalsIgnoreCase(FLAG_TRUE) || 
				accountProfile.getOptionTraderFlag().equalsIgnoreCase(FLAG_TRUE) ||
				accountProfile.getMarginTraderFlag().equalsIgnoreCase(FLAG_TRUE) ||
				positions.getSglLgl().equalsIgnoreCase(FLAG_TRUE)) {
			return "High";
			
		}
		else if((positions.getEtfHoldingFlag().equalsIgnoreCase(FLAG_TRUE) || 
				positions.getEquitiesHoldingFlag().equalsIgnoreCase(FLAG_TRUE)) &&
				age<40) {
			return "Medium";
		}
		else if((positions.getBondsHoldingFlag().equalsIgnoreCase(FLAG_TRUE) ||
				positions.getEtfHoldingFlag().equalsIgnoreCase(FLAG_TRUE) ||
				(positions.getBondsHoldingFlag().equalsIgnoreCase(FLAG_FALSE) &&
						positions.getBondsHoldingFlag().equalsIgnoreCase(FLAG_FALSE)&&
						positions.getOptionsHoldingFlag().equalsIgnoreCase(FLAG_FALSE) &&
						positions.getEquitiesHoldingFlag().equalsIgnoreCase(FLAG_FALSE)
						) ) &&age>40
				) {
			return "Low";
			
		}
		
		return risk;
		
	}
	
	
	public Integer calculateAge(String dob) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	      Date date = formatter.parse(dob);
	      //Converting obtained Date object to LocalDate object
	      Instant instant = date.toInstant();
	      ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
	      LocalDate givenDate = zone.toLocalDate();
	      //Calculating the difference between given date to current date.
	      Period period = Period.between(givenDate, LocalDate.now());
		
		return period.getYears();
		
	}


	public String calculateIndexScore(String valueText, String risk) {
		// TODO Auto-generated method stub
		Integer riskValue=null;
		Integer marketmoodIndex=null;
		
		if(risk.equalsIgnoreCase(RISK_HIGH)) {
			riskValue=5;
		}else if(risk.equalsIgnoreCase(RISK_MEDIUM)){
			riskValue=3; 
		}else if(risk.equalsIgnoreCase(RISK_LOW)) {
			riskValue=1;
		}
		
		System.out.println("-----Riskkvalue"+riskValue);
		System.out.println("-----INDEX from now"+valueText);
		if(valueText.equalsIgnoreCase(INDEX_EXTREME_FEAR)) {
			marketmoodIndex=1;
			
		}
		else if(valueText.equalsIgnoreCase(INDEX_FEAR)){ 
			marketmoodIndex=2;
		}
		else if(valueText.equalsIgnoreCase(INDEX_EXTREME_GREED)){ 
			marketmoodIndex=4;
		}else { 
			//for neutral also we will be considering as greed
			marketmoodIndex=3;
		}
		
		System.out.println("-----marketmoodIndex"+marketmoodIndex);
		return Integer.toString(riskValue+marketmoodIndex);
	}


	public String calculateRiskType(String indexScore) {
		
		if(indexScore!=null) {
			if(indexScore.equalsIgnoreCase("8")||indexScore.equalsIgnoreCase("9")) {
				return "Very Aggressive";
				
			}
			else if(indexScore.equalsIgnoreCase("6")||indexScore.equalsIgnoreCase("7")) {
				return "Aggressive";
				
			}else if(indexScore.equalsIgnoreCase("3") || indexScore.equalsIgnoreCase("4") || indexScore.equalsIgnoreCase("5")) {
				return "Moderate";
				
			}else if (indexScore.equalsIgnoreCase("2")||indexScore.equalsIgnoreCase("1")) {
				return "Conservative";
				
			}
		}
		// TODO Auto-generated method stub
		return null;
	}

}
