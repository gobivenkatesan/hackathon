package com.hcl.smartasset.advisor.app.controller;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class SocialMediaHyperIndexAPI 
{
	@GetMapping("/socialMediaHypeIndex/{symbol}")
	public String getSocialMediaHyperIndexDetails(@PathVariable(value = "symbol") String symbol)
	{
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create(
						"https://cryptocurrency-news-and-social-media-indices.p.rapidapi.com/volatility/reddit/ticker/"
								+ symbol + "/past_days/10"))
				.header("x-rapidapi-key", "fc16372826msh96c2e4e7ebd99acp14b6f2jsn702852d13d60")
				.header("x-rapidapi-host", "cryptocurrency-news-and-social-media-indices.p.rapidapi.com")
				.method("GET", HttpRequest.BodyPublishers.noBody()).build();

		HttpResponse<String> response = null;

		try 
		{
			response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
			System.out.println(response.body());
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		} 
		catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
		
		return response.body();
	}
}
