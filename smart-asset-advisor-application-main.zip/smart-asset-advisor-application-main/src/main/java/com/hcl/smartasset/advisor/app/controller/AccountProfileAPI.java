package com.hcl.smartasset.advisor.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.smartasset.advisor.app.business.BasketRecommendationBusiness;
import com.hcl.smartasset.advisor.app.invoker.MarketMoodIndexInvoker;
import com.hcl.smartasset.advisor.app.mapper.AccountProfileResponseMapper;
import com.hcl.smartasset.advisor.app.model.AccountProfile;
import com.hcl.smartasset.advisor.app.model.Positions;
import com.hcl.smartasset.advisor.app.repository.BasketRecommendationRepository;

import com.hcl.smartasset.advisor.app.ro.MarketMoodIndexResponse;
import com.hcl.smartasset.advisor.app.ro.AccountProfileRO.AccountProfileResponse;


@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class AccountProfileAPI {
	
	
	@Autowired
	BasketRecommendationRepository basketRecommendationRepository;
	
	
	@RequestMapping("accountProfile/{userId}")
	
	public AccountProfileResponse getAccountProfileByUserId(
			@PathVariable (value="userId") String userId) {
		
		AccountProfile accountProfile=null;
		Positions position =null;
		Integer age=null;
		MarketMoodIndexResponse marketMoodResponse=new MarketMoodIndexResponse();
		AccountProfileResponse accountProfileResponse=new AccountProfileResponse();
		BasketRecommendationBusiness basketRecommendationBusiness=new BasketRecommendationBusiness();
		MarketMoodIndexInvoker marketMoodIndexInvoker=new MarketMoodIndexInvoker();
		AccountProfileResponseMapper accountProfileResponseMapper=new AccountProfileResponseMapper();
		
		
		try {
		accountProfile=basketRecommendationRepository.fetchAccountDetailsByUserId(userId);
		//accountProfileResponse.setAccountProfile(accountProfile);
		
		System.out.println("response from db "+accountProfile.toString());
		if(!accountProfile.getDateOfBirth().isEmpty()) {
			age=basketRecommendationBusiness.calculateAge(accountProfile.getDateOfBirth());
			accountProfileResponse.setAge(Integer.toString(age));
			
			System.out.println("Age from dob "+age);
		}
		
		marketMoodResponse=marketMoodIndexInvoker.getMarketMoodIndexDetails();
		System.out.println("Market Mood Index from API "+marketMoodResponse.toString());
		
		//accountProfileResponse.setMarketMoodIndexResponse(marketMoodResponse);
		
		//System.out.println("Account Profile from API "+accountProfileResponse.toString());
		
		
		position=basketRecommendationRepository.findPositionsByUserId(userId);
		
		System.out.println("response from db "+position.toString());
		accountProfileResponse=accountProfileResponseMapper
				.mapResponseForAccountProfile(accountProfile,marketMoodResponse,accountProfileResponse,position);
		
	}
		catch (Exception e){
			System.out.println("Exception"+e.getMessage());
			System.out.println("Exception due to "+e.getStackTrace());
			
		}
		
		return accountProfileResponse;
	}
	
	

}
