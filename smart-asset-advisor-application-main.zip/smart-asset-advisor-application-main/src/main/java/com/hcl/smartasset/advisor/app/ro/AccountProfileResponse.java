package com.hcl.smartasset.advisor.app.ro;

import com.hcl.smartasset.advisor.app.model.AccountProfile;

public class AccountProfileResponse {
	
	private AccountProfile accountProfile;
	
	private MarketMoodIndexResponse marketMoodIndexResponse;
	
	private Integer age;

	
	
	public AccountProfile getAccountProfile() {
		return accountProfile;
	}

	public void setAccountProfile(AccountProfile accountProfile) {
		this.accountProfile = accountProfile;
	}

	public MarketMoodIndexResponse getMarketMoodIndexResponse() {
		return marketMoodIndexResponse;
	}

	public void setMarketMoodIndexResponse(MarketMoodIndexResponse marketMoodIndexResponse) {
		this.marketMoodIndexResponse = marketMoodIndexResponse;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}
	
	
	

	@Override
	public String toString() {
		return "AccountProfileResponse [accountProfile=" + accountProfile + ", marketMoodIndexResponse="
				+ marketMoodIndexResponse + ", age=" + age + "]";
	}
	
	

}
