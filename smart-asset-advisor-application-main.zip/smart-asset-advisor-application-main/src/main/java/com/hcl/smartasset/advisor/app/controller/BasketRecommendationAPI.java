package com.hcl.smartasset.advisor.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.smartasset.advisor.app.business.BasketRecommendationBusiness;
import com.hcl.smartasset.advisor.app.invoker.MarketMoodIndexInvoker;
import com.hcl.smartasset.advisor.app.mapper.BasketRecommendationMapper;
import com.hcl.smartasset.advisor.app.model.AccountProfile;
import com.hcl.smartasset.advisor.app.model.BasketRecommendation;
import com.hcl.smartasset.advisor.app.model.Positions;
import com.hcl.smartasset.advisor.app.repository.BasketRecommendationRepository;
import com.hcl.smartasset.advisor.app.ro.MarketMoodIndexResponse;
import com.hcl.smartasset.advisor.app.ro.BasketRecommendationRO.BasketRecommendationResponse;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class BasketRecommendationAPI {
	
	@Autowired
	BasketRecommendationRepository basketRecommendationRepository;
	
	
	@RequestMapping("/")
	String home() {
		System.out.println("Smart Advisor Tool");
		return "Smart Asset Advisor Tool";
	}

	@GetMapping("/accountInfo")
	public String  getAccountProfile() {
		return "Successfully retrieved account details from AccountProfileAPI";
		/*
		 * HttpResponse<String> response =
		 * Unirest.get("https://fear-and-greed-index.p.rapidapi.com/v1/fgi")
		 * .header("x-rapidapi-key",
		 * "651067aaaemsh00c9f1f0fdfd32dp1bcae2jsn0844109c973c")
		 * .header("x-rapidapi-host", "fear-and-greed-index.p.rapidapi.com")
		 * .asString();
		 * 
		 * System.out.print(response.toString());
		 */
		
		
		/*
		  OkHttpClient client = new OkHttpClient();
		  
		  Request request = new Request.Builder()
		  .url("https://fear-and-greed-index.p.rapidapi.com/v1/fgi") .get()
		  .addHeader("x-rapidapi-key",
		  "651067aaaemsh00c9f1f0fdfd32dp1bcae2jsn0844109c973c")
		  .addHeader("x-rapidapi-host", "fear-and-greed-index.p.rapidapi.com")
		  .build();
		  
		  Response response = client.newCall(request).execute();
}*/
		 
}
	
	
	@GetMapping("/basketRecommendation/{userId}")
	public BasketRecommendationResponse getAccountProfileByUserId(
			@PathVariable (value="userId") String userId ){
		
		AccountProfile accountProfile=null;
		BasketRecommendationResponse basketRecommendationResponse=null;
		BasketRecommendationMapper basketRecommendationMapper=new BasketRecommendationMapper();
		Positions positions=null;
		List<BasketRecommendation> basketRecommendation=null;
		BasketRecommendationBusiness basketRecommendationBusiness=new BasketRecommendationBusiness();
		MarketMoodIndexInvoker marketMoodIndexInvoker=new MarketMoodIndexInvoker();
		String risk ="";
		//HttpResponse<String> response = null;
		String IndexScore="";
		String riskType="";
		MarketMoodIndexResponse marketMoodResponse=new MarketMoodIndexResponse();
		try {
		System.out.println("--request "+userId);
		
		//Account Profile DB Call
		//accountProfile=basketRecommendationRepository.findAccountProfileByUserId(userId);
		accountProfile=basketRecommendationRepository.fetchAccountDetailsByUserId(userId);
		System.out.println("response from Account Profile"+accountProfile.toString());
		
		//Positions DB call
		//positions=basketRecommendationRepository.findPositionsByUserId(userId);
		positions=basketRecommendationRepository.findPositionsByUserId(userId);
		
		System.out.println("response from Positions"+positions.toString());
		
		//calculate Risk
		risk=basketRecommendationBusiness.calculateRisk(accountProfile,positions);
		
		System.out.println("Risk calculation"+risk);
		
		
		
		//marketmodeIndex Call 
		
		marketMoodResponse=marketMoodIndexInvoker.getMarketMoodIndexDetails();
		System.out.println("Market Mood Index from API "+marketMoodResponse.toString());
		
		
		//index score calculation :
		
		System.out.println("-----marketvalue"+marketMoodResponse.getFgi().getNow().getValueText());
		IndexScore=basketRecommendationBusiness.calculateIndexScore(marketMoodResponse.getFgi().getNow().getValueText(),risk);

		
	System.out.println("Index score"+IndexScore);
	
	//Risk Type Calculation
	riskType=basketRecommendationBusiness.calculateRiskType(IndexScore);
	
	System.out.println("Risk type to call db "+riskType);
	
		
		//basket DB call 
	
	System.out.println("Risk and level"+risk +"Index Score"+IndexScore);
		basketRecommendation=basketRecommendationRepository.fetchbasketdetails(riskType);
		System.out.println("Response from DB "+basketRecommendation.size());
		for (BasketRecommendation basketRecommendation2 : basketRecommendation) {
			System.out.println("Response from DB "+basketRecommendation2.toString()) ;
		}
		
		
		//tokenResponse = response.getBody().as(Token.class);
		
		basketRecommendationResponse=basketRecommendationMapper.mapBasketReccomendation(basketRecommendation);
		
		System.out.println("--------------basket recomendation response"+basketRecommendationResponse.toString());
		
		
		}
		catch (Exception e){
			System.out.println("Exception"+e.getMessage());
			System.out.println("Exception due to "+e.getStackTrace());
			
		}
		
		return basketRecommendationResponse;
	}
	
	
	
	
	
}

