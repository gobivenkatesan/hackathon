import {applyMiddleware,combineReducers,compose,createStore} from 'react-redux';


import { combineReducers } from '@reduxjs/toolkit'
import DiscoverReducer from './reducers/discover-reducer'
export default function configureStore(initialState){
const reducer=combineReducers({




});


}