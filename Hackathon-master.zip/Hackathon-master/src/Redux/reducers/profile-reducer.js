import * as actionTypes from './../../Redux/action-types';
const initialState={
    profileSummary:{}
    
};

export default (state=initialState,action)=>{
    //console.log('action',action);
    switch(action.type){
        case actionTypes.PROFILE_SUCCESS:{
            return{
                ...state,
                profileSummary:action.payload
            };
        };
        case actionTypes.PROFILE_ERROR:{
            return{
                ...state,
                profileSummary:{}
            };
        }
        

    }
   return state; 
}