import * as actionTypes from './../../Redux/action-types';

const initialState={
    checkboxItem:[]
};

export default (state=initialState,action)=>{
    console.log('action',action);
    switch(action.type){
        case actionTypes.CHECKBOX_CLICKED:{
            return{
                ...state,
                checkboxItem:action.checkboxItem
            };
        }

    }
   return state; 
}