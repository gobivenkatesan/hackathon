import * as actionTypes from './../../Redux/action-types';
const initialState={
    loginResponse:false,
    userName:''
    
};

export default (state=initialState,action)=>{
    console.log('action',action);
    switch(action.type){
        case actionTypes.LOGIN_SUCCESS:{
            return{
                ...state,
                loginResponse:action.payload
            };
        };
        case actionTypes.LOGIN_ERROR:{
            return{
                ...state,
                loginResponse:false
            };
        };
        case actionTypes.STORE_USER_NAME:{
            return{
                ...state,
                userName:action.user
            };
        }

    }
   return state; 
}