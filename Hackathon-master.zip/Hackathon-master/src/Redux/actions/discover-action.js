import * as ActionTypes from './../../Redux/action-types'


export function  addCheckboxItem(item){
    console.log('items in action',item);
return{
type:ActionTypes.CHECKBOX_CLICKED,
checkboxItem:item
}
}