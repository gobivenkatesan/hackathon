import {getLoginResultService} from './../../Utils/Services';
import {LOGIN_SUCCESS,LOGIN_ERROR,STORE_USER_NAME} from './../action-types';

export function getLoginResult(username,pwd){
   // console.log('values in login action:',username + ' '+ pwd);
return (dispatch)=>{
    return getLoginResultService(username,pwd).then(
        res=>{
            //console.log('res value: ',res);
            dispatch(getLoginResultSuccess(res.data));
        },
        error=>{
            //console.log('failure status: ',error);
            dispatch(getLoginResultError());
        }
    );

};
};

const getLoginResultSuccess=(data)=>{
    //console.log('response: ',data);
    return{
        type:LOGIN_SUCCESS,
        payload:data
    }
}
const getLoginResultError=()=>{
    //console.log('response: ',data);
    return{
        type:LOGIN_ERROR
    }
}

export function storeUserName(data){
    return{
        type:STORE_USER_NAME,
        user:data
        }
}