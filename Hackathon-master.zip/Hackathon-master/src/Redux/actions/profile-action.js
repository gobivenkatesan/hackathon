import {getProfileSummaryService} from './../../Utils/Services';
import {PROFILE_SUCCESS,PROFILE_ERROR} from './../action-types';

export function getProfileSummaryDetails(username){
     console.log('values in profile action:',username);
 return (dispatch)=>{
     return getProfileSummaryService(username).then(
         res=>{
             console.log('res value: ',res);
             dispatch(getProfileSuccess(res.data));
         },
         error=>{
             console.log('failure status: ',error);
             dispatch(getProfileError());
         }
     );
 
 };
 };
 
 const getProfileSuccess=(data)=>{
     //console.log('response: ',data);
     return{
         type:PROFILE_SUCCESS,
         payload:data
     }
 }
 const getProfileError=()=>{
     //console.log('response: ',data);
     return{
         type:PROFILE_ERROR
     }
 }