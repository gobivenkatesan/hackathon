module.exports=[
{
   'heading':'All Weather Investing',
   'description':'One investment for all market conditions.Works for everyone',
   'minAmt':3501,
   'cagr': '11.47%',
   'risk':'Low Risk'
},
{
    'heading':'Equity & Gold',
    'description':'Create wealth with equities, stay protected with Gold.The sweet spot',
    'minAmt':241,
    'cagr': '11.66%',
    'risk':'Low Risk'
 },
 {
    'heading':'Low Risk- Smart Beta',
    'description':'A low volatile portfolio that aims for high returns. Passive investing with a twist',
    'minAmt':59832,
    'cagr': '17.82%',
    'risk':'Low Risk'
 },
 {
    'heading':'Divident Aristocrats',
    'description':'Companies that have been consistently increasing dividents. Extra goodness',
    'minAmt':43767,
    'cagr': '21.56%',
    'risk':'Moderate Risk'
 }

];