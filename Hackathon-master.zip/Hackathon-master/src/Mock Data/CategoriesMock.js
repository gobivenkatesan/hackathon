module.exports=[
    // 'Crypto',
    'Equities',
    'Chart Pattern-Stocks',
    'Funds'
];