module.exports = {
    'firstName': 'Abhinandhan',
    'lastName': 'Vardhaman',
    'mailId': 'someone@example.com',
    'ssn': '*****1234',
    'phone': '******1234',
    'age': '27',
    'eligibility': [
        {
            'heading': 'Day Trader',
            'value': 'yes'
        }, {
            'heading': 'Margin Trader',
            'value': 'no'
        }, {
            'heading': 'Option Trader',
            'value': 'yes'
        }
    ],
    'holdings': [
        {
            'heading': 'ETF',
            'value': 'yes'
        }, {
            'heading': 'Bonds',
            'value': 'no'
        }, {
            'heading': 'Equity',
            'value': 'yes'
        },
        {
            'heading': 'No-position',
            'value': 'no'
        }

    ],
    'bankAccounts': [
        {
            'accountNumber': '*5937',
            'bankName': 'LAKSHMI VILAS BANK'
        }
    ],
    'marketMood': {
        'now': {
            'level': 'Fear',
            'value': '0.43'
        },
        'previousClose':
        {
            'level': 'Neutral',
            'value': '51'
        }
        ,
        'weekAgo':
        {
            'level': 'Greed',
            'value': '52'
        }
        ,
        'monthAgo':
        {
            'level': 'Fear',
            'value': '53'
        }
        ,
        'yearAgo':
        {
            'level': 'Extreme Fear',
            'value': '54'
        }
    }

}

