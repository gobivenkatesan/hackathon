module.exports=[
    {
       'heading':'Crypto-All Weather Investing',
       'description':'One investment for all market conditions.Works for everyone',
       'risk':'Low Risk'
    },
    {
        'heading':'Crypto-Equity & Gold',
        'description':'Create wealth with equities, stay protected with Gold.The sweet spot',
        'risk':'Low Risk'
     },
     {
        'heading':'Crypto-Low Risk- Smart Beta',
        'description':'A low volatile portfolio that aims for high returns. Passive investing with a twist',
        'risk':'Low Risk'
     },
     {
        'heading':'Crypto-Divident Aristocrats',
        'description':'Companies that have been consistently increasing dividents. Extra goodness',
        'risk':'Moderate Risk'
     }
    
    ];