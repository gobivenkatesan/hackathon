import React from 'react';
import './App.css';
import Login from './Components/Login';
import DiscoverPage from './Components/Discovery/DiscoverPage';
import PaymentPage from './Components/Payment/PaymentPage'
import ProfileSummary from './Components/Profile/ProfileSummary';
import ResultPage from './Components/ResultPage';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import CollectiveDiscovery from './Components/Discovery/CollectiveDiscovery';
import CryptoPage from './Components/Discovery/CryptoPage';


function App() {
  return (
    <div className="App">
      <header className="App-header">
              <div className="wrapper">
      
      < BrowserRouter >
<Switch>
            <Route exact path="/Home" component={DiscoverPage} />
            <Route exact path="/Crypto" component={CryptoPage} />
            <Route exact path="/Discovery" component={CollectiveDiscovery} />
            <Route exact path="/Profile" component={ProfileSummary} />
            <Route exact path="/Result" component={ResultPage} />
            <Route exact path="/Payment" component={PaymentPage} />
            <Route exact path="/" component={Login} />
           
         </Switch>
</BrowserRouter>
    </div>
  
      </header>
    </div>
  );
}



export default App;
