import React from 'react';

import axios from 'axios';


export const getLoginResultService =(username,passwd)=>{
   let serviceURL=`http://13.82.30.39:8181/authenticate/${username}/${passwd}`;
    return axios.get(
        serviceURL
    );
};

export const getProfileSummaryService =(username)=>{
    console.log('username in service',username);
   let serviceURL=`http://13.82.30.39:8181/accountProfile/${username}`;
    return axios.get(
        serviceURL
    );
};
