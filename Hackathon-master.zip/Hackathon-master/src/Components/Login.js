import React from 'react';
import './../App.css';
import './../CSS-Files/LoginPage.css';
import Picture from './../images/img_avatar2.png';
import { getLoginResult,storeUserName } from './../Redux/actions/Login-action';
//import { propTypes } from 'react-bootstrap/esm/Image';
import PropTypes from 'prop-types';
import { bindActionCreators } from '@reduxjs/toolkit';
import { connect } from 'react-redux';
import axios from 'axios';

class Login extends React.Component {
  constructor(props) {
    super(props);
    //this.state = { loginStatus:this.props.loginResponse };
  }

  componentDidMount() {
    window.addEventListener('mousedown', this.handleClickOutside);
  }
  handleClickOutside = (event) => {

    let modal = document.getElementById('id01');
    //console.log('event:',event);
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }

  validateCredentials = () => {
    let name = document.getElementById('username').value;
    let secret = document.getElementById('password').value;

    //this.props.getLoginResult('HCL001','corevalueS1');

    /*Using promise so that the validity will be checked after the execution of the API call*/
    this.props.getLoginResult(name, secret).then(() => {
      if (!this.props.loginResponse) {
        document.getElementById('errorTag').className = 'errorShow';
      } else {
        this.props.storeUserName(name);
      }
    });
    let result = this.props.loginResponse;
    console.log('result: ', result);
  }

  closeWindow = () => {
    document.getElementById('id01').style.display = 'none';
  }

  openWindow = () => {
    document.getElementById('id01').style.display = 'block';
  }


  render() {

    if (this.props.loginResponse) {
      this.props.history.push('/Profile');
    }
    return (
      <div>
        <h2>Welcome to Smart Asset Advisor</h2>

        <button onClick={this.openWindow} style={{ width: 'auto' }} className='loginPageButtons'>Login</button>

        <div id="id01" className="modal">

          <div className="modal-content animate" >
            <div className="imgcontainer">
              <span onClick={this.closeWindow} className="close" title="Close Modal">&times;</span>
              <img src={Picture} alt="Avatar" className="avatar" />
            </div>

            <div className="container">
              <label for="uname"><b>Username</b></label>
              <input type="text" placeholder="Enter Username" name="uname" id="username" required className='textAlign' />

              <label for="psw"><b>Password</b></label>
              <input type="password" placeholder="Enter Password" name="psw" id="password" required className='textAlign' />

              <button type="button" onClick={this.validateCredentials} className='loginPageButtons'>Login</button>
              <label>
                <input type="checkbox" checked="checked" name="remember" /> Remember me
              </label>
              <div><span id="errorTag" className="dontShow">Invalid username/Password!</span></div>
            </div>

            <div class="container" style={{ backgroundColor: '#f1f1f1' }}>
              <button type="button" onClick={this.closeWindow} className="cancelbtn loginPageButtons">Cancel</button>
              <span className="psw">Forgot <a href="#">password?</a></span>
            </div>
          </div>
        </div>
      </div>
    )
  }
};

// export default Login;
Login.propTypes = {
  loginResponse: PropTypes.bool,
  getLoginResult: PropTypes.func,
  storeUserName:PropTypes.func
};

function mapDispatchToProps(dispatch) {
  return bindActionCreators({ getLoginResult,storeUserName }, dispatch);
}

export const mapStateToProps = (state) => {
  console.log('Login state', state);
  return {
    loginResponse: state.login.loginResponse
  };
};


export default connect(mapStateToProps, mapDispatchToProps)(Login);
