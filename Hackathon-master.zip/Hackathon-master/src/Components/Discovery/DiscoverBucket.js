import React from 'react';
import { FormCheck } from 'react-bootstrap';
//import { propTypes } from 'react-bootstrap/esm/Image';
import PropTypes from 'prop-types';
import Image from 'react-bootstrap/Image';
import './../../CSS-Files/DiscoverBucket.css';
import { bindActionCreators } from '@reduxjs/toolkit';
import { connect } from 'react-redux';
import { addCheckboxItem } from './../../Redux/actions/discover-action';

let riskClassValue = '';


class DiscoverBucket extends React.Component {

    constructor(props) {
        super(props);
    }

    riskClassCss = () => {
        //console.log('method is called')
        if (this.props.arrayItem.risk == 'Low Risk') {
            // console.log('entering the if')
            riskClassValue = "label low";
        } else if (this.props.arrayItem.risk == 'Moderate Risk') {
            // console.log('entering the if')
            riskClassValue = "label moderate";
        } else if (this.props.arrayItem.risk == 'High Risk') {
            // console.log('entering the if')
            riskClassValue = "label high";
        }
    }
    handleChange = (event) => {
        if (event.target.checked) {
            //alert('checkbox checked');
            let temp = this.props.checkboxItem;
            console.log('before push', temp);
            let currentItem = this.props.arrayItem;
            temp = [...temp, currentItem];
            console.log('after push', temp);
            this.props.addCheckboxItem(temp);
        } else {
            //alert('checkbox unchecked');
            let temp=this.props.checkboxItem;
            let ind=temp.findIndex(x => x ==this.props.arrayItem);
            console.log('index: ',ind);
             temp=temp.filter(x=>x!==this.props.arrayItem);
             console.log('after deletion:',temp);
              this.props.addCheckboxItem(temp);
              console.log('checkBoxItems after delete',this.props.checkboxItem);
        }
    }
    

    render() {
        console.log('checkBoxItems',this.props.checkboxItem);
        return (
            <div>
                <div className='imageAlignment'>
                    <Image src="https://www.w3schools.com/images/picture.jpg" fluid />

                    <div className='checkBoxAlignment'>
                        <FormCheck custom>
                            <FormCheck.Label>
                                <FormCheck.Input type="checkbox" name="checkbox-name" onChange={this.handleChange} />
                                <div className="custom-control-label"></div>
                            </FormCheck.Label>
                        </FormCheck>
                    </div>
                </div>
                <div className='textContent'>
                    <div className='discoverItemHeading'>
                        {this.props.arrayItem.heading}
                    </div>
                    <div className='discoverItemDescription'>
                        {this.props.arrayItem.description}
                    </div>
                    {/* <br /> */}
                    {/* <div className='discoverItemAmount'>
                        <div className='headingAlign'>Min. Amount</div>
                        <div>{this.props.arrayItem.minAmt}</div>
                    </div>
                    <div className='discoverItemCagr'>
                        <div className='headingAlign'>CAGR</div>
                        <div>{this.props.arrayItem.cagr}</div>
                    </div> */}
                    {this.riskClassCss()}
                    <div className='riskLabel'>
                        <span className={riskClassValue}>{this.props.arrayItem.risk}</span>
                    </div>
                </div>
                <hr />
            </div>
        )
    }

}

DiscoverBucket.propTypes = {
    arrayItem: PropTypes.array,
    checkboxItem: PropTypes.array,
    addCheckboxItem: PropTypes.func
};

function mapDispatchToProps(dispatch) {
    return bindActionCreators({ addCheckboxItem }, dispatch);
}

export const mapStateToProps = (state) => {
    //console.log('state', state);
    return {
        checkboxItem: state.discover.checkboxItem
    };
};


export default connect(mapStateToProps, mapDispatchToProps)(DiscoverBucket);

