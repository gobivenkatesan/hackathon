import React from 'react';
//import { propTypes } from 'react-bootstrap/esm/Image';
import PropTypes from 'prop-types';
import { bindActionCreators } from '@reduxjs/toolkit';
import { connect } from 'react-redux';
import { Container, Row, Col, Nav } from 'react-bootstrap';
import GaugeChart from 'react-gauge-chart';
import './../../CSS-Files/CryptoPage.css';
import { addCheckboxItem } from './../../Redux/actions/discover-action';
import CryptoPageMock from './../../Mock Data/CryptoPageMock';
import CryptoTile from './CryptoTile';


class CryptoPage extends React.Component {
    constructor(props) {
        super(props);
    }

    populateCryptoTile = (arrayVal) => {
        return arrayVal.map((item, index) => {
            return (<Col xl={4}><CryptoTile tileItem={item} /></Col>);
        })

    }

    populateBuyTableContent=(arrayItem)=>{
        return arrayItem.map((item, index) => {
            return (
                <tr >
                    <td>{item.exchange}</td>
                    <td >{item.size}</td>
                    <td >{item.price}</td>
                </tr>
            );

        })

    }

    populateSellTableContent=(arrayItem)=>{
        return arrayItem.map((item, index) => {
            return (
                <tr >
                    <td>{item.price}</td>
                    <td >{item.size}</td>
                    <td >{item.exchange}</td>
                </tr>
            );

        })

    }


    render() {
        return (
            <div>
                <h3>Welcome to Crypto Page!!!</h3>
                <Container>
                    <Row>
                        {this.populateCryptoTile(CryptoPageMock.cryptoCurrency)}
                    </Row>
                    <Row>
                        {/* <Col> */}
                            <span className='gaugeAlign'>
                                <Row ><span className='gaugeHeading'>Fear and Greed Index</span></Row>
                                <Row ><GaugeChart id="gauge-chart2"
                                    nrOfLevels={5}
                                    percent={0.38}
                                    colors={["#ff0000", "#00ff00"]}
                                    textColor={"#000000"}
                                    formatTextValue={value => 'Fear (' + value + ')'}
                                    style={{ height: 171, width: 323 }}
                                />
                                    <div><span className='leftLabel'>Sell</span><span className='rightLabel'>Buy</span></div>
                                </Row>

                            </span>
                            <span className='gaugeAlign'>
                                <Row ><span className='gaugeHeading'>Social Index</span></Row>
                                <Row ><GaugeChart id="gauge-chart2"
                                    nrOfLevels={5}
                                    percent={0.38}
                                    colors={["#ff0000", "#00ff00"]}
                                    textColor={"#000000"}
                                    style={{ height: 171, width: 323 }}
                                />
                                    <div><span className='leftLabel'>Down</span><span className='rightLabel'>Up</span></div>
                                </Row>
                            </span>
                            <span className='gaugeAlign'>
                                <Row ><span className='gaugeHeading'>Market order flow</span></Row>
                                <Row ><GaugeChart id="gauge-chart2"
                                    nrOfLevels={5}
                                    percent={0.38}
                                    colors={["#ff0000", "#00ff00"]}
                                    textColor={"#000000"}
                                    style={{ height: 171, width: 323 }}
                                />
                                    <div><span className='leftLabel'>Sell</span><span className='rightLabel'>Buy</span></div>
                                </Row>
                            </span>

                        {/* </Col> */}
                        {/* <Col>
                            <table className='buyTable'>
                                <tr>
                                    <th colSpan="3">Buy</th>
                                </tr>
                                <tr>
                                    <th>Exchange</th>
                                    <th>Size</th>
                                    <th>Price</th>
                                </tr>
                                {this.populateBuyTableContent(CryptoPageMock.buyTable)}
                            </table>
                            <br />
                            <br />
                            <table className='sellTable'>
                                <tr>
                                    <th colSpan="3">Sell</th>
                                </tr>
                                <tr>
                                    <th>Price</th>
                                    <th>Size</th>
                                    <th>Exchange</th>
                                </tr>
                                {this.populateSellTableContent(CryptoPageMock.sellTable)}
                            </table>
                        </Col> */}
                    </Row>
                    
                </Container>
            </div>

        );
    }

};

CryptoPage.propTypes = {
    checkboxItem: PropTypes.array,
    addCheckboxItem: PropTypes.func
};

function mapDispatchToProps(dispatch) {
    return bindActionCreators({ addCheckboxItem }, dispatch);
}

export const mapStateToProps = (state) => {
    //console.log('state', state);
    return {
        checkboxItem: state.discover.checkboxItem
    };
};


export default connect(mapStateToProps, mapDispatchToProps)(CryptoPage); 