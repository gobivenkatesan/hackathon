import React from 'react';
import { FormCheck } from 'react-bootstrap';
//import { propTypes } from 'react-bootstrap/esm/Image';
import PropTypes from 'prop-types';
import './../../CSS-Files/CryptoPage.css';
import { bindActionCreators } from '@reduxjs/toolkit';
import { connect } from 'react-redux';
import FontAwesome from 'react-fontawesome';
import { addCheckboxItem } from './../../Redux/actions/discover-action';


class CryptoTile extends React.Component {

    constructor(props) {
        super(props);
       // this.state = { icon:'' };
    }

    determinIcon=()=>{
        let iconName='';
        console.log('entering icon method');
        if(this.props.tileItem.heading=='Bitcoin'){
            //this.setState({icon:'bitcoin'});
            iconName='bitcoin';
        }else {
            //this.setState({icon:'money'});
            iconName='money';
        }

        console.log('icon final value',iconName);

        return iconName;

    }

    render(){
        let icon=this.determinIcon();
        console.log('icon in state:',icon);
        console.log('tile Item: ',this.props.tileItem);
        let tile=this.props.tileItem;
        let sign='';
        let differenceLabelCss='';
        
        if(tile.difference=='raise'){
            sign='+';
            differenceLabelCss='differenceLabel differenceRaise';

        }else if(tile.difference=='fall'){
            sign='-';
            differenceLabelCss='differenceLabel differenceFall';
        }

        

return(
    <a className='card' href='#'>
        <div className='container'>
            <div className='firstRow'>
                <FontAwesome
                    className="super-crazy-colors"
                    name={icon}
                    size="lg"
                    style={{ color: 'orange' }}
                />
                <span style={{ paddingLeft: '3%' }}>{tile.heading}</span>
                <span className='timeLabel'>{tile.time + 'h'}</span>
            </div>
            <div className='secondRow'>
                <span >${tile.value}</span>
                <span className={differenceLabelCss}>{sign + tile.change + '%'}</span>
            </div>
        </div>
    </a>
        )

    }

};

CryptoTile.propTypes = {
    tileItem: PropTypes.array,
    checkboxItem: PropTypes.array,
    addCheckboxItem: PropTypes.func
};

function mapDispatchToProps(dispatch) {
    return bindActionCreators({ addCheckboxItem }, dispatch);
}

export const mapStateToProps = (state) => {
    //console.log('state', state);
    return {
        checkboxItem: state.discover.checkboxItem
    };
};


export default connect(mapStateToProps, mapDispatchToProps)(CryptoTile);