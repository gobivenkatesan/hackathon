import React from 'react';
import {Container,Row,Col} from 'react-bootstrap';
import DiscoverItem from './DiscoverBucket';
import './../../App.css';
import FontAwesome from 'react-fontawesome';


class DiscoverPage extends React.Component{
    constructor(props){
        super(props);
      }
      createListItem=(arrayItem)=>{
          return (
              <Container className='DisconverBanner'>
                  <Row>
                      {
                       arrayItem.map((item, index) => {
                          console.log('index:', index + ' item:', item.risk);
                            return(<Col xl={6}><DiscoverItem arrayItem={item} /></Col>);
                        })
                        }
                      

              </Row>

              </Container>
          );
    }
    
    goToPayment=()=>{
        this.props.history.push('/Payment');

    }



      render(){
          let discoverMock=(require('../../Mock Data/DiscoverPageMock'));
          console.log('mock:',discoverMock);
        
          return (

              <div>
                  
                      <Container>
                          <Row>
                              <Col><span className='discoverHeading'>Discover</span></Col>
                              <Col>
                              
                              <button type="button" className="btn btn-info cartAlignment" onClick={this.goToPayment}>
                                  Move to Cart
                          <FontAwesome
                              className="super-crazy-colors"
                              name="shopping-cart"
                              size="2x"
                          />
                      </button> 
                              </Col>
                          </Row>
                      </Container>

                  

                  <div>
                      {this.createListItem(discoverMock)}
                  </div>
              </div>
          )
      }


};

export default  DiscoverPage;






  