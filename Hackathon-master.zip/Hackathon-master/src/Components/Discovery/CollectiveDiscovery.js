import React from 'react';
import Image from 'react-bootstrap/Image';
import { Container, Row, Col, Navbar } from 'react-bootstrap';
import CryptoMock from './../../Mock Data/CryptoMock';
import EquityMock from './../../Mock Data/EquityMock';
import FundsMock from './../../Mock Data/FundsMock';
import ChartMock from './../../Mock Data/ChartPatternMock';
import DiscoverItem from './DiscoverBucket';
import Categories from './../../Mock Data/CategoriesMock';
import './../../App.css';
import './../../CSS-Files/DiscoverBucket.css';
import Photo from './../../images/img_avatar1.png';
import FontAwesome from 'react-fontawesome';

let cryptoMock = CryptoMock;
let equityMock = EquityMock;
let listVal = [];


class CollectiveDiscovery extends React.Component {
  constructor(props) {
    super(props);
  }

  constructCategory = () => {
    console.log('entering the method');
    let arrayVal = [];
    return (
      <div>
        {
          Categories.map((item, index) => {
            if (item == "Crypto") {
              console.log('entering if');
              console.log('category item:', item);
              arrayVal = CryptoMock;
            } else if (item == "Equities") {
              arrayVal = EquityMock;
            } else if (item == "Funds") {
              arrayVal = FundsMock;
            } else if (item == "Chart Pattern-Stocks") {
              arrayVal = ChartMock;
            }
            return (
              <div>
                <h3>{item}</h3>
                <Container className='DisconverBanner'>
                  <Row>
                    {
                      arrayVal.map((item, index) => {
                        return (<Col xl={6}><DiscoverItem arrayItem={item} /></Col>);
                      })
                    }
                  </Row>

                </Container>
              </div>
            )
          })
        }
      </div>
    )
  }


  goToProductSummary = () => {
    this.props.history.push('/ProductSummary');
  }

  render() {
    return (
      <div>
        <Navbar style={{ backgroundColor: "#071740", position: "sticky" }} variant="dark" fixed="top">
          <Navbar.Brand>
            <img src={Photo} alt="Avatar" class="avatar"></img>
            <Container>
              <span className='nameAlign'>Abhinandhan</span>
            </Container>

          </Navbar.Brand>
          <Container className='justify-content-end'>
            <button type="button" className="btn btn-info cartAlignment" onClick={this.goToProductSummary}>
              WatchList&nbsp;
                          <FontAwesome
                className="super-crazy-colors"
                name="dropbox"
                size="lg"
              />
            </button>
          </Container>


        </Navbar>

        <div className='content'>
          <h2 className='discoverHeading'>Discover</h2>
          <a className='card cryptoLabel' href='/Crypto'>
            <div className='container'>
              <div className='imageAlignment'>
                <Image src="https://www.w3schools.com/images/picture.jpg" fluid />
              </div>
              <div className='textContent'>
                <div className='discoverItemHeading'>
                  Crypto
                    </div>
                <div className='discoverItemDescription'>
                  Some Description
                    </div>

                <div className='riskLabel cryptoRiskLabel'>
                  <span className='high'>High Risk</span>
                </div>
              </div>

            </div>
          </a>
          <Container>
            {this.constructCategory()}
          </Container>
        </div>

      </div>

    );
  }

}

export default CollectiveDiscovery; 