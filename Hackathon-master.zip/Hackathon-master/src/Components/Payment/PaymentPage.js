import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { propTypes } from 'react-bootstrap/esm/Image';
import './../../CSS-Files/ProductSection.css'
import { connect } from 'react-redux';
import ProductSection from './ProductsSection';
import PaymentSection from './PaymentSection';



class PaymentPage extends React.Component {
    constructor(props) {
        super(props);
    }


    goToResults = () => {
        this.props.history.push('/Result');
    }
    render() {
        return (
            <div style={{ width: '1800px' }}>
                <div style={{ paddingBottom: '2%' }}>Welcome to Payment page!</div>
                <Container style={{ maxWidth: '67%' }}>
                    <Row>
                        <Col xl={7} className='backgroundContainer'><PaymentSection navigation={this.goToResults} /></Col>
                        <Col ><ProductSection /></Col>
                    </Row>
                </Container>
            </div>
        )
    }
}


PaymentPage.propTypes = {
    checkboxItem: propTypes.array,
    addCheckboxItem: propTypes.func
};


export const mapStateToProps = (state) => {
    return {
        checkboxItem: state.discover.checkboxItem
    };
};

export default connect(mapStateToProps, null)(PaymentPage);