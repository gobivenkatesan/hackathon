import React from 'react';
import { Link, Redirect, useHistory } from 'react-router-dom';
import { Container, Row, Col } from 'react-bootstrap';
import { propTypes } from 'react-bootstrap/esm/Image';
import './../../CSS-Files/PaymentSection.css';

import FontAwesome from 'react-fontawesome';
import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

class PaymentSection extends React.Component {
    constructor(props) {
        super(props);
    }
    

    render() {
        return (
            <div>
                <Container className='containerAlign'>
                    <Row >
                        <Col>
                            <h3>Payment</h3>
                            <label for="fname" className="labelAlign">Accepted Cards</label>
                            <div class="icon-container">

                                <FontAwesome
                                    className="super-crazy-colors"
                                    name="cc-visa"
                                    size="lg"
                                    style={{ color: 'navy' }}
                                />&nbsp;
                                <FontAwesome
                                    className="super-crazy-colors"
                                    name="cc-amex"
                                    size="lg"
                                    style={{ color: 'blue' }}
                                />&nbsp;
                                <FontAwesome
                                    className="super-crazy-colors"
                                    name="cc-mastercard"
                                    size="lg"
                                    style={{ color: 'red' }}
                                />&nbsp;
                                <FontAwesome
                                    className="super-crazy-colors"
                                    name="google-wallet"
                                    size="lg"
                                    style={{ color: 'orange' }}
                                />
                            </div>
                            <label for="cname" className="labelAlign">Name on Card</label>
                            <input type="text" id="cname" name="cardname" placeholder="Sidharth Abhimanyu" />
                            <label for="ccnum" className="labelAlign">Credit card number</label>
                            <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444" />
                            <label for="expmonth" className="labelAlign">Exp Month</label>
                            <input type="text" id="expmonth" name="expmonth" placeholder="September" />
                            <Row>
                                <Col>
                                    <label for="expyear" className="labelAlign">Exp Year</label>
                                    <input type="text" id="expyear" name="expyear" placeholder="2020"></input>
                                </Col>
                                <Col>
                                    <label for="cvv" className="labelAlign">CVV</label>
                                    <input type="text" id="cvv" name="cvv" placeholder="352"></input>
                                </Col>
                            </Row>
                        </Col>
                        <Col style={{ paddingTop: '2%' }}>
                            <h3>Billing Address</h3>
                            <label for="fname" className="labelAlign">
                                <FontAwesome
                                    className="super-crazy-colors"
                                    name="user"
                                    size="lg"
                                /> Full Name</label>
                            <input type="text" id="fname" name="firstname" placeholder="A.Sidharth" />
                            <label for="email" className="labelAlign">
                                <FontAwesome
                                className="super-crazy-colors"
                                name="envelope"
                                size="lg"
                            /> Email</label>
                            <input type="text" id="email" name="email" placeholder="sid@example.com" />
                            <label for="adr" className="labelAlign">
                                <FontAwesome
                                className="super-crazy-colors"
                                name="address-card"
                                size="lg"
                            /> Address</label>
                            <input type="text" id="adr" name="address" placeholder="542 W. 15th Street" />
                            <label for="city" className="labelAlign">
                                <FontAwesome
                                className="super-crazy-colors"
                                name="institution"
                                size="lg"
                            /> City</label>
                            <input type="text" id="city" name="city" placeholder="Chennai" />
                            <Row>
                                <Col>
                                    <label for="state" className="labelAlign">State</label>
                                    <input type="text" id="state" name="state" placeholder="TN"></input>
                                </Col>
                                <Col>
                                    <label for="zip" className="labelAlign">Zip</label>
                                    <input type="text" id="zip" name="zip" placeholder="10001"></input>
                                </Col>
                            </Row>
                        </Col>
                        <label>
                            <input type="checkbox" checked="checked" name="sameadr" /> Shipping address same as billing
                        </label>

                        <button type="button" className="btnAlign" onClick={this.props.navigation}>Invest Now</button>
                    </Row>
                </Container>
            </div>
        )
    }
}


PaymentSection.propTypes = {
    checkboxItem: propTypes.array,
    addCheckboxItem: propTypes.func,
    navigation:propTypes.func
};

export const mapStateToProps = (state) => {
    return {
        checkboxItem: state.discover.checkboxItem
    };
};

export default connect(mapStateToProps, null)(PaymentSection);













