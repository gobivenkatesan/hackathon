import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { propTypes } from 'react-bootstrap/esm/Image';
import './../../CSS-Files/ProductSection.css';
import FontAwesome from 'react-fontawesome';
import { connect } from 'react-redux';

class ProductSection extends React.Component {
    constructor(props) {
        super(props);
    } 

    populateProductContent = (productListItem) => {
        return (
            <div>
                {
                    productListItem.map((item, index) => {
                        return (
                            <Row className='pdtDisplay'>
                                <Col>
                                    {item.heading}
                                </Col>
                                <Col className="price">
                                    ${item.minAmt}
                                </Col>
                            </Row>
                        );
                    })
                }

            </div>
        )
    }

    calculateTotal(items) {
        let total = 0;
        items.map((item, index) => {
            total = total + item.minAmt;
        })
        return total;
    }

    render() {
        return (
            <div>
                <div className='backgroundContainer'>
                    <Container>
                        <Row>
                            <Col><h4>Cart</h4></Col>
                            <Col><FontAwesome
                                className="super-crazy-colors"
                                name="shopping-cart"
                                size="lg"
                            />{this.props.checkboxItem.length}</Col>
                        </Row>
                        {this.populateProductContent(this.props.checkboxItem)}
                        <hr className='totalLineStyling'></hr>
                        <Row>
                            <Col>Total</Col>
                            <Col><h4>${this.calculateTotal(this.props.checkboxItem)}</h4></Col>
                        </Row>
                    </Container>

                </div>

            </div>
        )
    }
}


ProductSection.propTypes = {
    checkboxItem: propTypes.array,
    addCheckboxItem: propTypes.func
};

export const mapStateToProps = (state) => {
    return {
        checkboxItem: state.discover.checkboxItem
    };
};

export default connect(mapStateToProps, null)(ProductSection);
