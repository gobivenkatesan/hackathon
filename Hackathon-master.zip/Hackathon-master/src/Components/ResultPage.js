import React from 'react';
//import useWindowSize from 'react-use/lib/useWindowSize';
import Confetti from 'react-confetti';
import FontAwesome from 'react-fontawesome';


class ResultPage extends React.Component{
    constructor(props){
        super(props);
        
      }
      
      render(){
        //const { width, height } = useWindowSize();    
          return (

              <div>
                 <Confetti
      width={window.innerWidth}
      height={window.innerHeight}
    /> 
          <h2>Your order has been placed!</h2> 
          <h3>Thank you for doing business with us!!</h3>           
              </div>
          )
      }


};

export default  ResultPage;






  