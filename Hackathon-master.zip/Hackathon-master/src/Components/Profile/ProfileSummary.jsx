import React from 'react';
//import {getLoginResult}from './../Redux/actions/Login-action';
//import { propTypes } from 'react-bootstrap/esm/Image';
import PropTypes from 'prop-types';
import { bindActionCreators } from '@reduxjs/toolkit';
import { connect } from 'react-redux';
import { Container, Row, Col, Form } from 'react-bootstrap';
import './../../CSS-Files/ProfilePage.css';
import GaugeChart from 'react-gauge-chart';
import FontAwesome from 'react-fontawesome';
import ProfileMock from './../../Mock Data/ProfileSummaryMock';
import Photo from './../../images/img_avatar1.png';
import {getProfileSummaryDetails} from './../../Redux/actions/profile-action';
import axios from 'axios';

class ProfileSummary extends React.Component {
    constructor(props) {
        super(props);
        //this.state = { profileData:{},userName:this.props.userName };
    }
    
    
//     

     static getDerivedStateFromProps (nextProps, prevState) {
//    Check props data and state are same
         console.log('nextProps:',nextProps);
         console.log('prevState:',prevState);
         console.log('this:',this);
        // if(nextProps.profileSummary==={}){
        //     //props.getProfileSummaryDetails(props.userName) ;
        //     console.log('nextProps:',nextProps);
        //     console.log('prevState:',prevState);
        //     nextProps.getProfileSummaryDetails(nextProps.userName);
            
        // }
     }


    goToDiscover = () => {
        this.props.history.push('/Discovery');

    }

disableSwitch=(event)=>{
event.target.checked='false';
}


    populateTableItemWithSwitch = (arrayItem) => {
        return arrayItem.map((item, index) => {
            //console.log('index:', index + ' item:', item.heading + 'value:', item.value);
            if (item.value == 'yes') {
                //console.log('entering yes');
                return (
                    <tr key={item.heading}>
                        <td>{item.heading}</td>
                        <td >
                            <label class="switch">
                                <input type="checkbox" checked onclick="return false;" />
                                <span class="slider round"></span>
                            </label>
                        </td>
                    </tr>
                );

            } else if (item.value == 'no') {
                //console.log('entering no');
                return (
                    <tr>
                        <td>{item.heading}</td>
                        <td >
                            <label class="switch" style={{pointerEvents:'none'}}>
                            <input type="checkbox"  onclick="return false;" />
                                <span class="slider round"></span>
                            </label>

                        </td>
                    </tr>
                );
            }
        })
    }

    populateMarketMoodLevel = (level) => {
        let cssValue = '';
        if (level == 'Neutral') {
            cssValue = 'neutral';

        } else if (level == 'Greed') {
            cssValue = 'greed';

        } else if (level == 'Fear') {
            cssValue = 'fear';

        } else if (level == 'Extreme Fear') {
            cssValue = 'extreme';

        }
        return (
            <Row className={cssValue}>{level}</Row>
        );
    }

    populateMarketMoodValue = (value, level) => {
        let cssValue = '';
        if (level == 'Neutral') {
            cssValue = 'dot circleNeutral';

        } else if (level == 'Greed') {
            cssValue = 'dot circleGreed';

        } else if (level == 'Fear') {
            cssValue = 'dot circleFear';

        } else if (level == 'Extreme Fear') {
            cssValue = 'dot circleExtreme';

        }

        return (
            <Col><span className={cssValue}>{value}</span></Col>
        );


    }


    render() {
        console.log('render is called...................... ');
        //console.log('test mockData: ', ProfileMock.marketMood.previousClose.level);
        console.log('render:',this.props.profileSummary);
        

        
        let mockData = ProfileMock;
        return (

            <div>
                <button type="button" className="btn btn-info cartAlignment" onClick={this.goToDiscover}>
                    Discover More&nbsp;
                          <FontAwesome
                        className="super-crazy-colors"
                        name="line-chart"
                        size="lg"
                    />
                </button>
                <h1 style={{ textAlign: 'left' }}>Profile</h1>

                <hr />

                <Container>
                    <Row className='nameSection'>
                        <Col>
                        <img src={Photo} alt="Avatar" class="avatar"></img>
                        {mockData.firstName + ' ' + mockData.lastName}
                        </Col>
                    </Row>
                    <hr />
                    <Row>
                        <Col>
                            <Row>
                                <table className='tableContent'>
                                    <tr  >
                                        <td >
                                            <h3 >Account</h3>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>E-Mail</td>
                                        <td>{mockData.mailId}</td>
                                    </tr>
                                    <tr>
                                        <td>SSN</td>
                                        <td>{mockData.ssn}</td>
                                    </tr>
                                    <tr>
                                        <td>Phone</td>
                                        <td>{mockData.phone}</td>
                                    </tr>
                                    <tr>
                                        <td>Age</td>
                                        <td>{mockData.age}</td>
                                    </tr>
                                </table>


                            </Row>
                            <hr />
                            <Row>
                                <div>
                                    <table className='tableContent'>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <h3>Eligibility</h3>
                                                </td>
                                            </tr>
                                            {this.populateTableItemWithSwitch(mockData.eligibility)}

                                        </tbody>
                                    </table>

                                </div>
                            </Row>
                            <hr />
                            <Row>
                                <table className='tableContent'>
                                    <tr>
                                        <td>
                                            <h3>Holdings</h3>
                                        </td>
                                    </tr>
                                    {this.populateTableItemWithSwitch(mockData.holdings)}
                                </table>
                            </Row>

                        </Col>
                        <Col>
                            <Row style={{paddingBottom:'19%'}}>
                                <h3>Bank Accounts</h3>
                                <div className='accountsAlignment'><span>{mockData.bankAccounts[0].accountNumber}</span>&nbsp;&nbsp;<span className='bankNameDisplay'>{mockData.bankAccounts[0].bankName}</span></div>

                            </Row>
                            <hr />
                            <Row style={{ height: '100%' }}>
                                <h3>Market Mood Index</h3>
                                <Col className='alignMarketContent'>
                                    <Row>
                                        <Row>
                                            <Col style={{ textAlign: 'right' }}><span style={{ fontWeight: 'bold' }}>Now: </span></Col>
                                            <Col>{this.populateMarketMoodLevel(mockData.marketMood.now.level)} </Col>
                                        </Row>

                                        <Row>
                                            <GaugeChart id="gauge-chart2"
                                                nrOfLevels={4}
                                                percent={mockData.marketMood.now.value}
                                                formatTextValue={value => mockData.marketMood.now.level+'('+value+')'}
                                                colors={["#ff0000", "#00ff00"]}
                                                textColor={"#000000"}
                                            />

                                        </Row>

                                    </Row>
                                    <Row>
                                        <Col>
                                            <Row>
                                                <Col className='marketMoodContent'>
                                                    <Row className='marketMoodHeading'>Previous close</Row>
                                                    {this.populateMarketMoodLevel(mockData.marketMood.previousClose.level)}
                                                </Col>
                                                {this.populateMarketMoodValue(mockData.marketMood.previousClose.value, mockData.marketMood.previousClose.level)}
                                            </Row>
                                            <hr className='marketMood' />
                                            <Row>
                                                <Col className='marketMoodContent'>
                                                    <Row className='marketMoodHeading'>1 week ago</Row>
                                                    {this.populateMarketMoodLevel(mockData.marketMood.weekAgo.level)}
                                                </Col>
                                                {this.populateMarketMoodValue(mockData.marketMood.weekAgo.value, mockData.marketMood.weekAgo.level)}
                                            </Row>
                                            <hr className='marketMood' />
                                            <Row>
                                                <Col className='marketMoodContent'>
                                                    <Row className='marketMoodHeading'>1 month ago</Row>
                                                    {this.populateMarketMoodLevel(mockData.marketMood.monthAgo.level)}
                                                </Col>
                                                {this.populateMarketMoodValue(mockData.marketMood.monthAgo.value, mockData.marketMood.monthAgo.level)}
                                            </Row>
                                            <hr className='marketMood' />
                                            <Row>
                                                <Col className='marketMoodContent'>
                                                    <Row className='marketMoodHeading'>1 year ago</Row>
                                                    {this.populateMarketMoodLevel(mockData.marketMood.yearAgo.level)}
                                                </Col>
                                                {this.populateMarketMoodValue(mockData.marketMood.yearAgo.value, mockData.marketMood.yearAgo.level)}
                                            </Row>
                                        </Col>
                                    </Row>
                                </Col>
                            </Row>
                        </Col>
                    </Row>
                </Container>
            </div>
        )
    }
};

//export default ProfileSummary;

ProfileSummary.propTypes = {
    userName:PropTypes.string,
    getProfileSummaryDetails:PropTypes.func,
    profileSummary:PropTypes.object
  };
  
  function mapDispatchToProps(dispatch) {
    return bindActionCreators({ getProfileSummaryDetails }, dispatch);
  }
  
  export const mapStateToProps = (state) => {
    console.log('Profile state', state);
    return {
        userName: state.login.userName,
        profileSummary:state.profile.profileSummary
    };
  };
  
  
  export default connect(mapStateToProps, mapDispatchToProps)(ProfileSummary);