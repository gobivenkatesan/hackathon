import { configureStore } from '@reduxjs/toolkit';
import LoginReducer from './../Redux/reducers/login-reducer';
import DiscoverReducer from './../Redux/reducers/discover-reducer';
import ProfileReducer from './../Redux/reducers/profile-reducer';

export default configureStore({
  reducer: {
    
    discover: DiscoverReducer,
    login:LoginReducer,
    profile:ProfileReducer
  },
});
