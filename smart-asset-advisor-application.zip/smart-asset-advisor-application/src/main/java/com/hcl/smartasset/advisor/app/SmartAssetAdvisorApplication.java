package com.hcl.smartasset.advisor.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartAssetAdvisorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartAssetAdvisorApplication.class, args);
	}
}
